/* 演示数据：全部为虚构数据，仅用于功能演示，不含任何真实企业信息 */
window.DEMO = {
  supplier: {
    id: 'SUP-001',
    name: '苏州精工五金有限公司',
    short: '精工五金',
    avatar: '精',
    category: '紧固件 / 密封件 / 传动件',
    contact: '周强 · 销售内勤',
    phone: '0512-6677****',
    settlement: '月结 30 天',
    taxRate: 13,
    rating: 'A-'
  },
  period: {
    key: '2026-10',
    label: '2026年10月',
    range: '2026-10-01 至 2026-10-31',
    cutoff: '2026-11-03'
  },
  periodOptions: [
    { value: '2026-10', label: '2026年10月', enabled: true },
    { value: '2026-09', label: '2026年9月（已归档）', enabled: false }
  ],
  statementMeta: {
    docNo: 'ST-202610',
    submittedBy: '供应商业务员 周强',
    submittedAt: '2026-10-31 18:20',
    channel: '供应商门户上传（PDF 转表格）'
  },

  /* 采购订单：7 行 */
  orders: [
    { docNo: 'PO-261001', lineNo: 10, date: '2026-10-02', itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', spec: '镀锌 8.8级', unit: '个', qty: 20000, price: 0.85, dueDate: '2026-10-10' },
    { docNo: 'PO-261001', lineNo: 20, date: '2026-10-02', itemCode: 'MAT-B014', itemName: '平垫圈 M8', spec: '304 不锈钢', unit: '个', qty: 30000, price: 0.12, dueDate: '2026-10-10' },
    { docNo: 'PO-261002', lineNo: 10, date: '2026-10-05', itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', spec: '304 锻造', unit: '件', qty: 800, price: 46.00, dueDate: '2026-10-18' },
    { docNo: 'PO-261003', lineNo: 10, date: '2026-10-08', itemCode: 'MAT-Z204', itemName: '深沟球轴承 6204-2RS', spec: '双面密封', unit: '套', qty: 1200, price: 12.50, dueDate: '2026-10-22' },
    { docNo: 'PO-261004', lineNo: 10, date: '2026-10-09', itemCode: 'MAT-S025', itemName: 'O型密封圈 φ25×2.4', spec: '丁腈橡胶 NBR', unit: '个', qty: 5000, price: 0.36, dueDate: '2026-10-25' },
    { docNo: 'PO-261005', lineNo: 10, date: '2026-10-12', itemCode: 'MAT-C081', itemName: '滚子链 08B-1', spec: '1.5 米/条', unit: '米', qty: 300, price: 28.00, dueDate: '2026-10-28' },
    { docNo: 'PO-261006', lineNo: 10, date: '2026-10-14', itemCode: 'MAT-N008', itemName: '六角螺母 M8', spec: '镀锌 8级', unit: '个', qty: 15000, price: 0.28, dueDate: '2026-10-30' }
  ],

  /* 送货单：12 行 */
  deliveries: [
    { docNo: 'DN-2610-001', date: '2026-10-03', poNo: 'PO-261001', itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', unit: '个', qty: 8000, price: 0.85 },
    { docNo: 'DN-2610-001', date: '2026-10-03', poNo: 'PO-261001', itemCode: 'MAT-B014', itemName: '平垫圈 M8', unit: '个', qty: 12000, price: 0.12 },
    { docNo: 'DN-2610-002', date: '2026-10-11', poNo: 'PO-261001', itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', unit: '个', qty: 12000, price: 0.85 },
    { docNo: 'DN-2610-002', date: '2026-10-11', poNo: 'PO-261001', itemCode: 'MAT-B014', itemName: '平垫圈 M8', unit: '个', qty: 18000, price: 0.12 },
    { docNo: 'DN-2610-003', date: '2026-10-19', poNo: 'PO-261002', itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 400, price: 46.00 },
    { docNo: 'DN-2610-004', date: '2026-10-20', poNo: 'PO-261002', itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 400, price: 46.00 },
    { docNo: 'DN-2610-005', date: '2026-10-23', poNo: 'PO-261003', itemCode: 'MAT-Z204', itemName: '深沟球轴承 6204-2RS', unit: '套', qty: 600, price: 12.50 },
    { docNo: 'DN-2610-006', date: '2026-10-26', poNo: 'PO-261003', itemCode: 'MAT-Z204', itemName: '深沟球轴承 6204-2RS', unit: '套', qty: 500, price: 12.50 },
    { docNo: 'DN-2610-007', date: '2026-10-27', poNo: 'PO-261004', itemCode: 'MAT-S025', itemName: 'O型密封圈 φ25×2.4', unit: '个', qty: 5000, price: 0.36 },
    { docNo: 'DN-2610-008', date: '2026-10-29', poNo: 'PO-261005', itemCode: 'MAT-C081', itemName: '滚子链 08B-1', unit: '米', qty: 300, price: 28.00 },
    { docNo: 'DN-2610-009', date: '2026-10-30', poNo: '', itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', unit: '个', qty: 2000, price: 0.85 },
    { docNo: 'DN-2610-010', date: '2026-10-31', poNo: 'PO-261006', itemCode: 'MAT-N008', itemName: '六角螺母 M8', unit: '个', qty: 8000, price: 0.28 },
    { docNo: 'DN-2610-011', date: '2026-10-31', poNo: 'PO-261006', itemCode: 'MAT-N008', itemName: '六角螺母 M8', unit: '个', qty: 7000, price: 0.28 }
  ],

  /* 供应商对账单：10 行（第 5 行为重复计账） */
  statements: [
    { lineNo: 1, itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', unit: '个', qty: 22000, price: 0.85, refs: ['DN-2610-001', 'DN-2610-002', 'DN-2610-009'] },
    { lineNo: 2, itemCode: 'MAT-B014', itemName: '平垫圈 M8', unit: '个', qty: 30000, price: 0.13, refs: ['DN-2610-001', 'DN-2610-002'] },
    { lineNo: 3, itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 400, price: 46.00, refs: ['DN-2610-003'] },
    { lineNo: 4, itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 400, price: 46.00, refs: ['DN-2610-004'] },
    { lineNo: 5, itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 400, price: 46.00, refs: ['DN-2610-003'] },
    { lineNo: 6, itemCode: 'MAT-Z204', itemName: '深沟球轴承 6204-2RS', unit: '套', qty: 1100, price: 12.50, refs: ['DN-2610-005', 'DN-2610-006'] },
    { lineNo: 7, itemCode: 'MAT-S025', itemName: 'O型密封圈 φ25×2.4', unit: '个', qty: 5000, price: 0.36, refs: ['DN-2610-007'] },
    { lineNo: 8, itemCode: 'MAT-C081', itemName: '滚子链 08B-1', unit: '米', qty: 300, price: 28.00, refs: ['DN-2610-008'] },
    { lineNo: 9, itemCode: 'MAT-C081', itemName: '滚子链 08B-1', unit: '米', qty: 100, price: 28.00, refs: [] },
    { lineNo: 10, itemCode: 'MAT-N008', itemName: '六角螺母 M8', unit: '个', qty: 14700, price: 0.28, refs: ['DN-2610-010', 'DN-2610-011'] }
  ],

  /* 发票：6 行（缺 O型密封圈） */
  invoices: [
    { invoiceNo: 'INV-33829701', date: '2026-10-31', itemCode: 'MAT-B001', itemName: '六角螺栓 M8×40', unit: '个', qty: 20000, price: 0.85, taxRate: 13 },
    { invoiceNo: 'INV-33829701', date: '2026-10-31', itemCode: 'MAT-B014', itemName: '平垫圈 M8', unit: '个', qty: 30000, price: 0.13, taxRate: 13 },
    { invoiceNo: 'INV-33829702', date: '2026-10-31', itemCode: 'MAT-F050', itemName: '不锈钢法兰 DN50', unit: '件', qty: 800, price: 46.00, taxRate: 13 },
    { invoiceNo: 'INV-33829702', date: '2026-10-31', itemCode: 'MAT-Z204', itemName: '深沟球轴承 6204-2RS', unit: '套', qty: 1100, price: 12.50, taxRate: 13 },
    { invoiceNo: 'INV-33829703', date: '2026-10-31', itemCode: 'MAT-C081', itemName: '滚子链 08B-1', unit: '米', qty: 300, price: 28.00, taxRate: 13 },
    { invoiceNo: 'INV-33829704', date: '2026-10-31', itemCode: 'MAT-N008', itemName: '六角螺母 M8', unit: '个', qty: 14700, price: 0.28, taxRate: 13 }
  ],

  /* 历史对账（虚构） */
  history: [
    {
      key: '2026-09', label: '2026年9月', statementTotal: 96800.00, confirmed: 94350.00,
      deduction: 2450.00, exceptionCount: 5, closedCount: 5, missingInvoice: 0,
      status: '已归档', archivedAt: '2026-10-12', owner: '王敏',
      types: { '单价差异': 2, '数量不符': 1, '重复计账': 0, '缺单漏单': 2, '发票差异': 0 },
      note: '链条短缺 100 件已补送货；垫圈单价差异按订单价核减。'
    },
    {
      key: '2026-08', label: '2026年8月', statementTotal: 88320.00, confirmed: 87140.00,
      deduction: 1180.00, exceptionCount: 4, closedCount: 4, missingInvoice: 0,
      status: '已归档', archivedAt: '2026-09-11', owner: '王敏',
      types: { '单价差异': 1, '数量不符': 1, '重复计账': 1, '缺单漏单': 1, '发票差异': 0 },
      note: '重复计账 1 项（法兰 200 件）已由供应商删除。'
    },
    {
      key: '2026-07', label: '2026年7月', statementTotal: 91500.00, confirmed: 88480.00,
      deduction: 3020.00, exceptionCount: 6, closedCount: 5, missingInvoice: 1,
      status: '已归档', archivedAt: '2026-08-13', owner: '李倩',
      types: { '单价差异': 2, '数量不符': 1, '重复计账': 1, '缺单漏单': 1, '发票差异': 1 },
      note: '1 项缺票在次月 8 日补齐，已解除暂缓付款。'
    }
  ],

  /* 历史结论复用库 */
  reuseLibrary: [
    {
      id: 'D-07',
      title: '小额单价差异按订单价核减',
      rule: '单价差异 ≤ 0.02 元/件 且影响金额 ≤ 500 元时，直接按采购订单价核减，不单独发起申诉。',
      origin: '2026-09 对账，#D-07',
      appliesTo: 'price',
      defaultOn: true
    },
    {
      id: 'D-05',
      title: '短缺物料补送货后计入下期',
      rule: '对账数量多于送货数量的部分，要求供应商补送货并附送货单，补足后计入下期对账，不在本期确认。',
      origin: '2026-09 对账，#D-05',
      appliesTo: 'noSupport',
      defaultOn: true
    },
    {
      id: 'D-09',
      title: '缺票须次月 10 日前补齐',
      rule: '对账已确认但未开票的物料，暂缓对应金额付款，供应商须在次月 10 日前补开发票。',
      origin: '2026-07 对账，#D-09',
      appliesTo: 'invoice',
      defaultOn: true
    }
  ],

  /* 上期未结事项 */
  carryOver: [
    { id: 'C-2026-09-01', text: '深沟球轴承 6204-2RS 欠交 100 套', amount: 1250.00, relatedItem: 'MAT-Z204' }
  ]
};
