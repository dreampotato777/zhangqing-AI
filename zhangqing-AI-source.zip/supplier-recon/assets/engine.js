/* 对账引擎：规则驱动的单据匹配与差异识别（纯前端、可离线运行） */
window.ReconEngine = (function () {
  'use strict';

  var DEFAULT_CONFIG = {
    priceTolerancePct: 0.5,
    qtyTolerance: 0,
    amountTolerance: 1,
    matchKey: 'itemCode',
    periodEnded: true
  };

  var TYPE = {
    PRICE: '单价差异',
    QTY: '数量不符',
    DUP: '重复计账',
    MISSING: '缺单漏单',
    INVOICE: '发票差异'
  };

  var SEVERITY_WEIGHT = { high: 3, medium: 2, low: 1 };

  function round2(n) {
    return Math.round((Number(n || 0) + 1e-9) * 100) / 100;
  }
  function num(n) {
    var v = Number(n);
    return isNaN(v) ? 0 : v;
  }
  function qty(n) {
    return Math.round(num(n) * 1000) / 1000;
  }
  function fmtNum(n, digits) {
    var d = typeof digits === 'number' ? digits : 2;
    return num(n).toLocaleString('zh-CN', { minimumFractionDigits: d, maximumFractionDigits: d });
  }
  function fmtQty(n) {
    return fmtNum(n, qty(n) === Math.round(qty(n)) ? 0 : 3);
  }
  function money(n) {
    return '¥' + fmtNum(n, 2);
  }
  function pct(n) {
    return fmtNum(n, 2) + '%';
  }

  function stripUnit(v) {
    return String(v == null ? '' : v).replace(/^¥|￥/g, '').replace(/,/g, '').trim();
  }

  function normalizeConfig(config) {
    var c = {};
    Object.keys(DEFAULT_CONFIG).forEach(function (k) {
      c[k] = config && config[k] != null ? config[k] : DEFAULT_CONFIG[k];
    });
    c.priceTolerancePct = num(c.priceTolerancePct);
    c.qtyTolerance = num(c.qtyTolerance);
    c.amountTolerance = num(c.amountTolerance);
    return c;
  }

  function reconcile(docs, config, opts) {
    docs = docs || {};
    var cfg = normalizeConfig(config);
    opts = opts || {};
    var orders = docs.orders || [];
    var deliveries = docs.deliveries || [];
    var statements = docs.statements || [];
    var invoices = docs.invoices || [];

    var items = {};
    var exceptions = [];

    function item(code, name, unit) {
      if (!items[code]) {
        items[code] = {
          code: code, name: name || code, unit: unit || '',
          orderQty: 0, orderAmount: 0, orderPrice: 0, orderRows: [],
          deliveredQty: 0, deliveredAmount: 0, deliveredPoQty: 0,
          noPoQty: 0, noPoAmount: 0, noPoRows: [],
          stmtRawQty: 0, stmtRawAmount: 0, stmtQty: 0, stmtAmount: 0,
          stmtRows: [], dupRows: [],
          invoiceQty: 0, invoiceAmount: 0, invoiceRows: [],
          priceDeduct: 0, noSupportDeduct: 0, noPoDeduct: 0,
          recognized: 0
        };
      }
      if (!items[code].name && name) items[code].name = name;
      if (!items[code].unit && unit) items[code].unit = unit;
      return items[code];
    }

    /* ---------- 1. 采购订单 ---------- */
    orders.forEach(function (r) {
      var it = item(r.itemCode, r.itemName, r.unit);
      it.orderQty += num(r.qty);
      it.orderAmount += num(r.qty) * num(r.price);
      it.orderRows.push(r);
    });
    Object.keys(items).forEach(function (k) {
      var it = items[k];
      it.orderAmount = round2(it.orderAmount);
      it.orderPrice = it.orderQty ? it.orderAmount / it.orderQty : 0;
    });

    /* ---------- 2. 送货单 ---------- */
    deliveries.forEach(function (r) {
      var it = item(r.itemCode, r.itemName, r.unit);
      it.deliveredQty += num(r.qty);
      it.deliveredAmount += num(r.qty) * num(r.price);
      if (String(r.poNo || '').trim()) {
        it.deliveredPoQty += num(r.qty);
      } else {
        it.noPoQty += num(r.qty);
        it.noPoAmount += num(r.qty) * num(r.price);
        it.noPoRows.push(r);
      }
    });

    /* ---------- 3. 对账单：重复计账识别（按 物料 + 关联送货单 去重） ---------- */
    var refSeen = {};
    var dupGroups = [];
    statements.forEach(function (r) {
      var it = item(r.itemCode, r.itemName, r.unit);
      it.stmtRawQty += num(r.qty);
      it.stmtRawAmount += num(r.qty) * num(r.price);
      it.stmtRows.push(r);

      var refs = (r.refs || []).filter(function (x) { return String(x || '').trim(); });
      var dupOf = null;
      refs.forEach(function (ref) {
        var key = r.itemCode + '|' + String(ref).trim();
        if (refSeen[key]) {
          if (!dupOf) dupOf = refSeen[key];
        } else {
          refSeen[key] = { row: r, ref: String(ref).trim() };
        }
      });

      if (dupOf) {
        it.dupRows.push({ row: r, original: dupOf.row, ref: dupOf.ref });
        it.stmtRawQty = it.stmtRawQty; // 保留原始行，用于向供应商展示
      } else {
        it.stmtQty += num(r.qty);
        it.stmtAmount += num(r.qty) * num(r.price);
      }
    });

    /* ---------- 4. 发票 ---------- */
    invoices.forEach(function (r) {
      var it = item(r.itemCode, r.itemName, r.unit);
      it.invoiceQty += num(r.qty);
      it.invoiceAmount += num(r.qty) * num(r.price);
      it.invoiceRows.push(r);
    });

    Object.keys(items).forEach(function (k) {
      var it = items[k];
      it.stmtRawAmount = round2(it.stmtRawAmount);
      it.stmtAmount = round2(it.stmtAmount);
      it.deliveredAmount = round2(it.deliveredAmount);
      it.noPoAmount = round2(it.noPoAmount);
      it.invoiceAmount = round2(it.invoiceAmount);
    });

    /* ---------- 5. 规则 1：重复计账 ---------- */
    Object.keys(items).forEach(function (k) {
      var it = items[k];
      it.dupRows.forEach(function (d, i) {
        var amount = round2(num(d.row.qty) * num(d.row.price));
        exceptions.push({
          id: 'dup-' + k + '-' + (d.ref || i) + '-' + d.row.lineNo,
          type: TYPE.DUP,
          subtype: '重复计账',
          severity: 'high',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 重复计账',
          short: '第 ' + d.row.lineNo + ' 行与第 ' + d.original.lineNo + ' 行引用同一张送货单 ' + d.ref + '，重复金额 ' + money(amount),
          amount: amount,
          qty: num(d.row.qty),
          direction: 'deduct',
          evidence: [
            { kind: '对账单', docNo: 'ST-202610', lineNo: d.original.lineNo, date: opts.statementDate || '', qty: num(d.original.qty), price: num(d.original.price), amount: round2(num(d.original.qty) * num(d.original.price)), note: '首次引用 ' + d.ref },
            { kind: '对账单', docNo: 'ST-202610', lineNo: d.row.lineNo, date: opts.statementDate || '', qty: num(d.row.qty), price: num(d.row.price), amount: amount, note: '重复引用同一送货单' },
            { kind: '送货单', docNo: d.ref, lineNo: '', date: '', qty: num(d.row.qty), price: num(d.row.price), amount: amount, note: '仅一张送货单' }
          ],
          comparison: {
            stmtRawQty: it.stmtRawQty, stmtValidQty: it.stmtQty,
            duplicateQty: num(d.row.qty), amount: amount
          },
          suggestion: '要求供应商删除第 ' + d.row.lineNo + ' 行后重新盖章；核对时已将该行从有效对账金额中剔除。',
          refText: d.ref + ' / 第 ' + d.row.lineNo + ' 行'
        });
      });
    });

    /* ---------- 6. 规则 2：单价差异 ---------- */
    Object.keys(items).forEach(function (k) {
      var it = items[k];
      if (it.orderQty <= 0 || it.stmtQty <= 0) return;
      var stmtPrice = it.stmtAmount / it.stmtQty;
      var orderPrice = it.orderPrice;
      if (!orderPrice) return;
      var diff = stmtPrice - orderPrice;
      var diffPct = (diff / orderPrice) * 100;
      if (Math.abs(diffPct) <= cfg.priceTolerancePct) return;
      var amount = round2(Math.abs(diff) * it.stmtQty);
      var severity = Math.abs(diffPct) >= 3 ? 'high' : 'medium';
      var invoiceRows = it.invoiceRows.filter(function (x) { return true; });
      var invoiceExcess = 0;
      if (invoiceRows.length) {
        var invPrice = it.invoiceQty ? it.invoiceAmount / it.invoiceQty : 0;
        invoiceExcess = round2(Math.max(0, (invPrice - orderPrice) * Math.min(it.invoiceQty, it.stmtQty)));
      }
      var evidence = [];
      it.stmtRows.filter(function (r) { return (it.dupRows || []).every(function (d) { return d.row.lineNo !== r.lineNo; }); }).forEach(function (r) {
        evidence.push({ kind: '对账单', docNo: 'ST-202610', lineNo: r.lineNo, date: '', qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '含税单价 ' + fmtNum(r.price, 4) });
      });
      it.orderRows.forEach(function (r) {
        evidence.push({ kind: '采购订单', docNo: r.docNo, lineNo: r.lineNo, date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '约定单价 ' + fmtNum(r.price, 4) });
      });
      if (invoiceRows.length) {
        invoiceRows.forEach(function (r) {
          evidence.push({ kind: '发票', docNo: r.invoiceNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '按对账单单价开具' });
        });
      }
      exceptions.push({
        id: 'price-' + k,
        type: TYPE.PRICE,
        subtype: diff > 0 ? '对账单价高于订单价' : '对账单价低于订单价',
        severity: severity,
        itemCode: k,
        itemName: it.name,
        unit: it.unit,
        title: it.name + ' 对账单价' + (diff > 0 ? '高于' : '低于') + '订单价',
        short: '对账单价 ' + fmtNum(stmtPrice, 4) + ' vs 订单价 ' + fmtNum(orderPrice, 4) + '，影响 ' + money(amount),
        amount: amount,
        qty: it.stmtQty,
        direction: diff > 0 ? 'deduct' : 'info',
        priceDiffAbs: Math.abs(diff),
        diffPct: diffPct,
        invoiceExcess: invoiceExcess,
        evidence: evidence,
        comparison: {
          orderQty: it.orderQty, orderPrice: orderPrice, orderAmount: it.orderAmount,
          stmtQty: it.stmtQty, stmtPrice: stmtPrice, stmtAmount: it.stmtAmount,
          deliveredQty: it.deliveredQty, invoiceQty: it.invoiceQty, invoiceAmount: it.invoiceAmount
        },
        suggestion: diff > 0
          ? '建议按采购订单价 ' + fmtNum(orderPrice, 4) + ' 元/' + (it.unit || '单位') + ' 核减 ' + money(amount) + '；发票 ' + (it.invoiceRows[0] ? it.invoiceRows[0].invoiceNo : '') + ' 需同步红冲重开。'
          : '对账单价低于订单价，需确认是否含促销折让或价格调整协议，避免后续补价争议。',
        refText: it.orderRows[0] ? it.orderRows[0].docNo : ''
      });
    });

    /* ---------- 7. 规则 3：缺单漏单（无采购订单 / 无送货支持） ---------- */
    Object.keys(items).forEach(function (k) {
      var it = items[k];

      if (it.noPoQty > 0) {
        var amount = round2(it.noPoAmount);
        var evidence = it.noPoRows.map(function (r) {
          return { kind: '送货单', docNo: r.docNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '未关联采购订单' };
        });
        it.stmtRows.forEach(function (r) {
          evidence.push({ kind: '对账单', docNo: 'ST-202610', lineNo: r.lineNo, date: '', qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '供应商已计入对账' });
        });
        exceptions.push({
          id: 'nopo-' + k,
          type: TYPE.MISSING,
          subtype: '无采购订单',
          severity: 'high',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 无采购订单送货',
          short: '送货 ' + fmtQty(it.noPoQty) + ' ' + it.unit + ' 无对应采购订单，金额 ' + money(amount),
          amount: amount,
          qty: it.noPoQty,
          direction: 'deduct',
          evidence: evidence,
          comparison: { orderQty: it.orderQty, deliveredQty: it.deliveredQty, noPoQty: it.noPoQty, stmtQty: it.stmtQty },
          suggestion: '补开采购订单或按退货处理；未补齐订单前，该部分金额不纳入本期确认。',
          refText: it.noPoRows.map(function (r) { return r.docNo; }).join('、')
        });
      }

      var gap = it.stmtQty - it.deliveredQty;
      if (gap > cfg.qtyTolerance) {
        var gapAmount = round2(gap * (it.stmtQty ? it.stmtAmount / it.stmtQty : 0));
        var ev = [];
        it.stmtRows.forEach(function (r) {
          if ((it.dupRows || []).some(function (d) { return d.row.lineNo === r.lineNo; })) return;
          ev.push({ kind: '对账单', docNo: 'ST-202610', lineNo: r.lineNo, date: '', qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: (r.refs && r.refs.length) ? '关联 ' + r.refs.join('、') : '未关联送货单' });
        });
        it.deliveredQty > 0 && Object.keys(items).forEach(function () {});
        deliveries.filter(function (r) { return r.itemCode === k; }).forEach(function (r) {
          ev.push({ kind: '送货单', docNo: r.docNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: r.poNo ? '关联 ' + r.poNo : '无订单' });
        });
        exceptions.push({
          id: 'nosupport-' + k,
          type: TYPE.MISSING,
          subtype: '无送货单支持',
          severity: 'high',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 对账数量无送货单支持',
          short: '对账 ' + fmtQty(it.stmtQty) + ' vs 送货 ' + fmtQty(it.deliveredQty) + '，差额 ' + fmtQty(gap) + ' ' + it.unit,
          amount: gapAmount,
          qty: gap,
          direction: 'deduct',
          evidence: ev,
          comparison: { stmtQty: it.stmtQty, deliveredQty: it.deliveredQty, gap: gap, stmtAmount: it.stmtAmount },
          suggestion: '要求供应商补送货单并说明货物流向；补足前按送货数量确认，差额不计入本期应付。',
          refText: it.stmtRows.length ? ('ST-202610 第 ' + it.stmtRows[it.stmtRows.length - 1].lineNo + ' 行') : ''
        });
      } else if (gap < -cfg.qtyTolerance) {
        var under = -gap;
        var underAmount = round2(under * (it.stmtQty ? it.stmtAmount / it.stmtQty : it.orderPrice));
        var ev2 = [];
        it.stmtRows.forEach(function (r) {
          ev2.push({ kind: '对账单', docNo: 'ST-202610', lineNo: r.lineNo, date: '', qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '供应商计列' });
        });
        deliveries.filter(function (r) { return r.itemCode === k; }).forEach(function (r) {
          ev2.push({ kind: '送货单', docNo: r.docNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '我方签收' });
        });
        exceptions.push({
          id: 'understate-' + k,
          type: TYPE.QTY,
          subtype: '对账数量少计',
          severity: 'low',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 对账数量少计',
          short: '送货 ' + fmtQty(it.deliveredQty) + ' vs 对账 ' + fmtQty(it.stmtQty) + '，少计 ' + fmtQty(under) + ' ' + it.unit,
          amount: underAmount,
          qty: under,
          direction: 'info',
          evidence: ev2,
          comparison: { stmtQty: it.stmtQty, deliveredQty: it.deliveredQty, gap: under, stmtAmount: it.stmtAmount },
          suggestion: '少计部分本期按对账单金额确认，同时提示供应商补列，避免下期重复计账。',
          refText: 'ST-202610 第 ' + (it.stmtRows[0] ? it.stmtRows[0].lineNo : '') + ' 行'
        });
      }
    });

    /* ---------- 8. 规则 4：订单履约（超订单 / 未交齐） ---------- */
    Object.keys(items).forEach(function (k) {
      var it = items[k];
      if (it.orderQty <= 0) return;
      if (it.deliveredPoQty > it.orderQty + cfg.qtyTolerance) {
        var over = it.deliveredPoQty - it.orderQty;
        exceptions.push({
          id: 'overorder-' + k,
          type: TYPE.QTY,
          subtype: '超订单送货',
          severity: 'medium',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 超订单送货',
          short: '订单 ' + fmtQty(it.orderQty) + '，已送 ' + fmtQty(it.deliveredPoQty) + '，超送 ' + fmtQty(over),
          amount: round2(over * it.orderPrice),
          qty: over,
          direction: 'info',
          evidence: it.orderRows.concat(deliveries.filter(function (r) { return r.itemCode === k && r.poNo; })).map(function (r) {
            return { kind: r.docNo.indexOf('PO') === 0 ? '采购订单' : '送货单', docNo: r.docNo, lineNo: r.lineNo || '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '超订单部分需补订单' };
          }),
          comparison: { orderQty: it.orderQty, deliveredPoQty: it.deliveredPoQty, gap: over },
          suggestion: '超送部分需补签采购订单，否则按退货或下期冲抵处理。',
          refText: it.orderRows[0].docNo
        });
      } else if (it.orderQty > it.deliveredPoQty + cfg.qtyTolerance && cfg.periodEnded) {
        var lack = it.orderQty - it.deliveredPoQty;
        exceptions.push({
          id: 'undelivered-' + k,
          type: TYPE.MISSING,
          subtype: '订单未交齐',
          severity: 'medium',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 订单未交齐',
          short: '订单 ' + fmtQty(it.orderQty) + '，已送 ' + fmtQty(it.deliveredPoQty) + '，欠交 ' + fmtQty(lack),
          amount: round2(lack * it.orderPrice),
          qty: lack,
          direction: 'info',
          evidence: it.orderRows.map(function (r) {
            return { kind: '采购订单', docNo: r.docNo, lineNo: r.lineNo, date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '交期 ' + (r.dueDate || '') };
          }).concat(deliveries.filter(function (r) { return r.itemCode === k && r.poNo; }).map(function (r) {
            return { kind: '送货单', docNo: r.docNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '已签收' };
          })),
          comparison: { orderQty: it.orderQty, deliveredPoQty: it.deliveredPoQty, gap: lack, stmtQty: it.stmtQty },
          suggestion: '本期对账未多计，属订单履约缺口；建议转下期跟踪并催交，避免影响生产排程。',
          refText: it.orderRows.map(function (r) { return r.docNo; }).join('、')
        });
      }
    });

    /* ---------- 9. 规则 5：发票核对 ---------- */
    var priceExceptionByItem = {};
    exceptions.forEach(function (e) {
      if (e.type === TYPE.PRICE) priceExceptionByItem[e.itemCode] = e;
    });

    Object.keys(items).forEach(function (k) {
      var it = items[k];
      if (it.stmtQty <= 0) return;
      var priceEx = priceExceptionByItem[k];
      var deduction = round2((priceEx ? priceEx.amount : 0));
      var noSupport = round2(it.stmtQty > it.deliveredQty ? (it.stmtQty - it.deliveredQty) * (it.stmtAmount / it.stmtQty) : 0);
      var noPo = round2(it.noPoAmount);
      var recognized = round2(Math.max(0, it.stmtAmount - deduction - noSupport - noPo));
      it.recognized = recognized;

      var diff = recognized - it.invoiceAmount;
      if (diff > cfg.amountTolerance) {
        var ev = it.stmtRows.map(function (r) {
          return { kind: '对账单', docNo: 'ST-202610', lineNo: r.lineNo, date: '', qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '已确认金额 ' + money(it.stmtAmount) };
        });
        it.invoiceRows.forEach(function (r) {
          ev.push({ kind: '发票', docNo: r.invoiceNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '已开票' });
        });
        if (!it.invoiceRows.length) {
          ev.push({ kind: '发票', docNo: '—', lineNo: '', date: '', qty: 0, price: 0, amount: 0, note: '未检索到本期发票' });
        }
        exceptions.push({
          id: 'invoice-missing-' + k,
          type: TYPE.INVOICE,
          subtype: '未开票',
          severity: 'medium',
          itemCode: k,
          itemName: it.name,
          unit: it.unit,
          title: it.name + ' 对账已确认但未开票',
          short: '确认 ' + money(recognized) + '，已开票 ' + money(it.invoiceAmount) + '，缺票 ' + money(diff),
          amount: diff,
          qty: it.invoiceQty ? it.invoiceQty : it.stmtQty,
          direction: 'invoice',
          evidence: ev,
          comparison: { stmtQty: it.stmtQty, stmtAmount: it.stmtAmount, recognized: recognized, invoiceQty: it.invoiceQty, invoiceAmount: it.invoiceAmount, gap: diff },
          suggestion: '暂缓缺票部分付款，要求供应商在次月 10 日前补开发票；补票后同步解除付款冻结。',
          refText: it.stmtRows.map(function (r) { return '第 ' + r.lineNo + ' 行'; }).join('、')
        });
      } else if (-diff > cfg.amountTolerance) {
        var excess = round2(-diff);
        if (priceEx) {
          priceEx.invoiceExcess = Math.max(priceEx.invoiceExcess || 0, excess);
        } else {
          exceptions.push({
            id: 'invoice-excess-' + k,
            type: TYPE.INVOICE,
            subtype: '发票多开',
            severity: 'medium',
            itemCode: k,
            itemName: it.name,
            unit: it.unit,
            title: it.name + ' 发票金额高于确认金额',
            short: '确认 ' + money(recognized) + '，已开票 ' + money(it.invoiceAmount) + '，多开 ' + money(excess),
            amount: excess,
            qty: it.invoiceQty,
            direction: 'invoice-excess',
            evidence: it.invoiceRows.map(function (r) {
              return { kind: '发票', docNo: r.invoiceNo, lineNo: '', date: r.date, qty: num(r.qty), price: num(r.price), amount: round2(num(r.qty) * num(r.price)), note: '开票金额' };
            }),
            comparison: { recognized: recognized, invoiceAmount: it.invoiceAmount, gap: excess },
            suggestion: '要求供应商红冲多开部分后重新开具，红冲完成前不确认超出金额。',
            refText: it.invoiceRows[0] ? it.invoiceRows[0].invoiceNo : ''
          });
        }
      }
    });

    /* ---------- 10. 汇总 ---------- */
    var itemList = Object.keys(items).map(function (k) { return items[k]; }).sort(function (a, b) {
      return b.stmtRawAmount - a.stmtRawAmount;
    });

    var statementRawTotal = round2(itemList.reduce(function (s, it) { return s + it.stmtRawAmount; }, 0));
    var statementValidTotal = round2(itemList.reduce(function (s, it) { return s + it.stmtAmount; }, 0));
    var duplicateTotal = round2(statementRawTotal - statementValidTotal);
    var confirmedTotal = round2(itemList.reduce(function (s, it) { return s + it.recognized; }, 0));
    var invoiceTotal = round2(itemList.reduce(function (s, it) { return s + it.invoiceAmount; }, 0));
    var deductionTotal = round2(exceptions.filter(function (e) {
      return e.direction === 'deduct' && e.type !== TYPE.DUP;
    }).reduce(function (s, e) { return s + e.amount; }, 0));
    var missingInvoiceTotal = round2(exceptions.filter(function (e) { return e.subtype === '未开票'; }).reduce(function (s, e) { return s + e.amount; }, 0));
    var invoiceExcessTotal = round2(exceptions.filter(function (e) {
      return e.type === TYPE.INVOICE && e.subtype === '发票多开';
    }).reduce(function (s, e) { return s + e.amount; }, 0) + exceptions.filter(function (e) { return e.type === TYPE.PRICE; }).reduce(function (s, e) { return s + (e.invoiceExcess || 0); }, 0));
    var undeliveredTotal = round2(exceptions.filter(function (e) { return e.subtype === '订单未交齐'; }).reduce(function (s, e) { return s + e.amount; }, 0));
    var understatedTotal = round2(exceptions.filter(function (e) { return e.subtype === '对账数量少计'; }).reduce(function (s, e) { return s + e.amount; }, 0));
    var supplierActionTotal = round2(deductionTotal + duplicateTotal + missingInvoiceTotal);

    var metrics = {
      statementRawTotal: statementRawTotal,
      statementValidTotal: statementValidTotal,
      duplicateTotal: duplicateTotal,
      deductionTotal: deductionTotal,
      confirmedTotal: confirmedTotal,
      invoiceTotal: invoiceTotal,
      invoiceNet: round2(invoiceTotal - confirmedTotal),
      missingInvoiceTotal: missingInvoiceTotal,
      invoiceExcessTotal: invoiceExcessTotal,
      undeliveredTotal: undeliveredTotal,
      understatedTotal: understatedTotal,
      supplierActionTotal: supplierActionTotal,
      exceptionCount: exceptions.length,
      highCount: exceptions.filter(function (e) { return e.severity === 'high'; }).length,
      mediumCount: exceptions.filter(function (e) { return e.severity === 'medium'; }).length,
      lowCount: exceptions.filter(function (e) { return e.severity === 'low'; }).length,
      itemCount: itemList.length,
      statementLineCount: statements.length,
      orderLineCount: orders.length,
      deliveryLineCount: deliveries.length,
      invoiceLineCount: invoices.length
    };

    /* ---------- 11. 异常排序 + 历史口径复用 ---------- */
    exceptions.sort(function (a, b) {
      var d = (SEVERITY_WEIGHT[b.severity] || 0) - (SEVERITY_WEIGHT[a.severity] || 0);
      if (d) return d;
      return b.amount - a.amount;
    });

    var reuse = opts.reuse || null;
    if (reuse && reuse.enabled) {
      var ids = reuse.ids || [];
      exceptions.forEach(function (e) {
        if (ids.indexOf('D-07') >= 0 && e.type === TYPE.PRICE && e.priceDiffAbs <= 0.02 && e.amount <= 500) {
          e.suggestedStatus = 'closed';
          e.reuseNote = '沿用 ' + (reuse.from || '上期') + ' 结论 D-07：单价差异 ≤ 0.02 元/件且影响 ≤ 500 元，按订单价核减，无需单独申诉。';
        }
        if (ids.indexOf('D-05') >= 0 && e.subtype === '无送货单支持') {
          e.suggestedStatus = 'supplier';
          e.reuseNote = '沿用 ' + (reuse.from || '上期') + ' 结论 D-05：短缺部分补送货后计入下期，不跨期重复计账。';
        }
        if (ids.indexOf('D-09') >= 0 && e.subtype === '未开票') {
          e.suggestedStatus = 'supplier';
          e.reuseNote = '沿用 ' + (reuse.from || '上期') + ' 结论 D-09：缺票须次月 10 日前补齐，期间暂缓对应金额付款。';
        }
      });
    }

    exceptions.forEach(function (e) {
      e.status = 'pending';
      e.history = [];
      if (!e.relatedText) e.relatedText = e.refText || '';
    });

    /* ---------- 12. 自检勾稽 ---------- */
    var checks = [
      {
        name: '对账单拆分勾稽',
        detail: '$' + fmtNum(statementRawTotal) + ' − 重复 ' + fmtNum(duplicateTotal) + ' = 有效 ' + fmtNum(statementValidTotal),
        pass: Math.abs((statementRawTotal - duplicateTotal) - statementValidTotal) <= 0.02
      },
      {
        name: '建议确认金额勾稽',
        detail: '有效 ' + fmtNum(statementValidTotal) + ' − 核减 ' + fmtNum(deductionTotal) + ' = 确认 ' + fmtNum(confirmedTotal),
        pass: Math.abs((statementValidTotal - deductionTotal) - confirmedTotal) <= 0.02
      },
      {
        name: '发票与确认金额勾稽',
        detail: '已开票 ' + fmtNum(invoiceTotal) + ' − 确认 ' + fmtNum(confirmedTotal) + ' = ' + fmtNum(invoiceTotal - confirmedTotal) + '（缺票 ' + fmtNum(missingInvoiceTotal) + ' / 多开 ' + fmtNum(invoiceExcessTotal) + '）',
        pass: Math.abs((invoiceTotal - confirmedTotal) - (invoiceExcessTotal - missingInvoiceTotal)) <= 0.02
      },
      {
        name: '重复行只剔除一次',
        detail: '重复行 ' + exceptions.filter(function (e) { return e.type === TYPE.DUP; }).length + ' 项，重复金额 ' + fmtNum(duplicateTotal),
        pass: duplicateTotal === round2(exceptions.filter(function (e) { return e.type === TYPE.DUP; }).reduce(function (s, e) { return s + e.amount; }, 0))
      },
      {
        name: '异常均有单据证据',
        detail: exceptions.length + ' 项异常全部可追溯到原始单据',
        pass: exceptions.every(function (e) { return e.evidence && e.evidence.length > 0; })
      }
    ];

    return {
      items: itemList,
      exceptions: exceptions,
      metrics: metrics,
      checks: checks,
      config: cfg,
      reuse: reuse,
      generatedAt: opts.now || new Date().toISOString()
    };
  }

  /* ---------- 差异说明（本地规则模板生成，不调用外部大模型） ---------- */
  function explain(e) {
    var u = e.unit || '单位';
    if (e.type === TYPE.PRICE) {
      var c = e.comparison;
      return '对账单按 ' + fmtNum(c.stmtPrice, 4) + ' 元/' + u + ' 计列「' + e.itemName + '」共 ' + fmtQty(e.qty) + ' ' + u +
        '，采购订单约定单价为 ' + fmtNum(c.orderPrice, 4) + ' 元/' + u + '，单价' + (e.diffPct > 0 ? '上浮' : '下浮') +
        ' ' + fmtNum(Math.abs(c.stmtPrice - c.orderPrice), 4) + ' 元（' + pct(Math.abs(e.diffPct)) + '），影响金额 ' + money(e.amount) +
        '。该差异超出 ' + fmtNum((e.tolerance || 0.5), 1) + '% 的单价容差，需按对账口径处理。' +
        (e.invoiceExcess ? ' 对应发票已按对账单价开具，多开 ' + money(e.invoiceExcess) + '，需红冲后重开。' : '');
    }
    if (e.type === TYPE.DUP) {
      var cd = e.comparison;
      return '对账单第 ' + (e.evidence[1] ? e.evidence[1].lineNo : '') + ' 行与第 ' + (e.evidence[0] ? e.evidence[0].lineNo : '') +
        ' 行引用同一张送货单 ' + e.refText.split(' / ')[0] + '，数量 ' + fmtQty(e.qty) + ' ' + u + '、单价 ' + fmtNum(e.evidence[0].price, 4) +
        ' 元，属重复计账，涉及金额 ' + money(e.amount) + '。该行已从有效对账金额中剔除，有效数量为 ' + fmtQty(cd.stmtValidQty) + ' ' + u + '。';
    }
    if (e.subtype === '无采购订单') {
      return '送货单 ' + e.refText + ' 共 ' + fmtQty(e.qty) + ' ' + u + '「' + e.itemName + '」未关联任何采购订单，金额 ' + money(e.amount) +
        '，供应商已将其计入本期对账。该批送货缺少订单依据，需补开订单或按退货处理后再确认付款。';
    }
    if (e.subtype === '无送货单支持') {
      var cs = e.comparison;
      return '对账单计列「' + e.itemName + '」' + fmtQty(cs.stmtQty) + ' ' + u + '，我方送货单可核销 ' + fmtQty(cs.deliveredQty) +
        ' ' + u + '，差额 ' + fmtQty(cs.gap) + ' ' + u + ' 没有对应送货记录，涉及金额 ' + money(e.amount) +
        '。需供应商补送货单并说明货物流向，补足前不计入本期应付。';
    }
    if (e.subtype === '订单未交齐') {
      var cu = e.comparison;
      return '采购订单 ' + e.refText + ' 订购 ' + fmtQty(cu.orderQty) + ' ' + u + '，本期累计送货 ' + fmtQty(cu.deliveredPoQty) +
        ' ' + u + '，尚欠 ' + fmtQty(cu.gap) + ' ' + u + '（按订单价约 ' + money(e.amount) + '）。供应商对账单未多计，属订单履约缺口，不影响本期确认金额，建议转下期跟踪并催交。';
    }
    if (e.subtype === '未开票') {
      var ci = e.comparison;
      return '本期对账建议确认「' + e.itemName + '」' + money(ci.recognized) + '，已开票 ' + money(ci.invoiceAmount) +
        '，缺票 ' + money(ci.gap) + '。按对账口径须在次月 10 日前补开发票，缺票部分暂缓付款。';
    }
    if (e.subtype === '对账数量少计') {
      var cq = e.comparison;
      return '本期送货「' + e.itemName + '」' + fmtQty(cq.deliveredQty) + ' ' + u + '，对账单仅计列 ' + fmtQty(cq.stmtQty) +
        ' ' + u + '，少计 ' + fmtQty(cq.gap) + ' ' + u + '（约 ' + money(e.amount) + '）。少计对我方有利，但可能导致下期重复计账，建议提示供应商补列后按对账单金额确认。';
    }
    return e.short || '';
  }

  /* ---------- 对账摘要生成 ---------- */
  function buildSummary(result, meta) {
    var m = result.metrics;
    var supplier = (meta && meta.supplier) || DEMO.supplier;
    var period = (meta && meta.period) || DEMO.period;
    var high = result.exceptions.filter(function (e) { return e.severity === 'high'; });
    var mid = result.exceptions.filter(function (e) { return e.severity === 'medium'; });
    var low = result.exceptions.filter(function (e) { return e.severity === 'low'; });
    var typeCount = {};
    result.exceptions.forEach(function (e) { typeCount[e.type] = (typeCount[e.type] || 0) + 1; });

    var sections = [];
    sections.push({
      title: '一、对账范围',
      body: period.label + '（' + period.range + '）就' + supplier.name + '的采购订单、送货单、对账单、发票四类单据进行逐条核对：' +
        '采购订单 ' + m.orderLineCount + ' 行、送货单 ' + m.deliveryLineCount + ' 行、对账单 ' + m.statementLineCount + ' 行、发票 ' + m.invoiceLineCount + ' 行，覆盖 ' + m.itemCount + ' 个物料。'
    });
    sections.push({
      title: '二、金额结论',
      body: '供应商对账单总额 ' + money(m.statementRawTotal) + '，剔除重复计账 ' + money(m.duplicateTotal) + ' 后有效金额 ' + money(m.statementValidTotal) +
        '；按采购订单价及送货记录核减 ' + money(m.deductionTotal) + '，本期建议确认 ' + money(m.confirmedTotal) + '。' +
        '已收发票 ' + money(m.invoiceTotal) + '，与确认金额相差 ' + money(Math.abs(m.invoiceNet)) + '（缺票 ' + money(m.missingInvoiceTotal) + '，多开 ' + money(m.invoiceExcessTotal) + '）。'
    });
    sections.push({
      title: '三、异常分布',
      body: '共识别异常 ' + m.exceptionCount + ' 项，其中高 ' + m.highCount + ' 项、中 ' + m.mediumCount + ' 项、低 ' + m.lowCount + ' 项。' +
        '按类型：单价差异 ' + (typeCount['单价差异'] || 0) + ' 项、数量不符 ' + (typeCount['数量不符'] || 0) + ' 项、重复计账 ' + (typeCount['重复计账'] || 0) + ' 项、' +
        '缺单漏单 ' + (typeCount['缺单漏单'] || 0) + ' 项、发票差异 ' + (typeCount['发票差异'] || 0) + ' 项。'
    });

    var top = result.exceptions.slice(0, 4);
    if (top.length) {
      sections.push({
        title: '四、重点事项',
        body: top.map(function (e, i) {
          return (i + 1) + '. ' + explain(e);
        }).join(' ')
      });
    }

    var actions = [];
    var dupEx = result.exceptions.filter(function (e) { return e.type === TYPE.DUP; });
    if (dupEx.length) actions.push('要求供应商删除对账单重复行（影响 ' + money(m.duplicateTotal) + '）并重新盖章');
    if (result.exceptions.some(function (e) { return e.type === TYPE.PRICE && e.direction === 'deduct'; })) {
      actions.push('按采购订单价核减单价差异 ' + money(result.exceptions.filter(function (e) { return e.type === TYPE.PRICE && e.direction === 'deduct'; }).reduce(function (s, e) { return s + e.amount; }, 0)) + '，同步红冲多开发票');
    }
    if (result.exceptions.some(function (e) { return e.subtype === '无采购订单'; })) actions.push('补齐无采购订单送货的订单依据或办理退货');
    if (result.exceptions.some(function (e) { return e.subtype === '无送货单支持'; })) actions.push('要求供应商补送短缺物料及送货单');
    if (m.missingInvoiceTotal > 0) actions.push('次月 10 日前补齐缺票 ' + money(m.missingInvoiceTotal) + '，否则暂缓对应付款');
    if (m.undeliveredTotal > 0) actions.push('订单未交齐部分转下期跟踪，并同步生产计划');
    if (result.reuse && result.reuse.enabled) actions.push('已复用 ' + result.reuse.from + ' 历史口径，自动套用 ' + (result.reuse.ids || []).length + ' 条结论，减少重复判断');

    sections.push({
      title: '五、处理建议',
      body: actions.map(function (a, i) { return (i + 1) + '. ' + a + '；'; }).join(' ') + '以上事项处理完成后，由采购与财务双方在确认单上签字归档。'
    });

    if (result.reuse && result.reuse.enabled) {
      sections.push({
        title: '六、历史复用说明',
        body: '本次对账复用 ' + result.reuse.from + ' 已归档结论：' + (result.reuse.ids || []).join('、') +
          '。其中小额单价差异自动按订单价核减，短缺与缺票事项按既有流程转入供应商待办，处理口径与上期保持一致。'
      });
    }

    var markdown = '# ' + supplier.name + ' ' + period.label + ' 对账摘要\n\n' +
      '生成时间：' + new Date().toLocaleString('zh-CN') + '\n\n' +
      sections.map(function (s) { return '## ' + s.title + '\n\n' + s.body; }).join('\n\n') + '\n\n' +
      '> 本摘要由对账规则模板生成，金额取自当前核对结果，归档前需人工复核。\n';

    return {
      sections: sections,
      markdown: markdown,
      highlights: [
        { label: '建议确认金额', value: money(m.confirmedTotal), hint: '对账有效金额 − 核减' },
        { label: '需供应商修正', value: money(m.supplierActionTotal), hint: '含重复计账 ' + money(m.duplicateTotal) },
        { label: '待补发票', value: money(m.missingInvoiceTotal), hint: '缺票 ' + result.exceptions.filter(function (e) { return e.subtype === '未开票'; }).length + ' 项' },
        { label: '待交付金额', value: money(m.undeliveredTotal), hint: '不影响本期确认' }
      ],
      meta: {
        supplierName: supplier.name,
        periodLabel: period.label,
        generatedAt: new Date().toLocaleString('zh-CN')
      }
    };
  }

  return {
    reconcile: reconcile,
    explain: explain,
    buildSummary: buildSummary,
    DEFAULT_CONFIG: DEFAULT_CONFIG,
    TYPE: TYPE,
    fmtNum: fmtNum,
    fmtQty: fmtQty,
    money: money,
    round2: round2
  };
})();
