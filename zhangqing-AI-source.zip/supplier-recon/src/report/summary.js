const TYPE_LABELS = {
  qty_diff: "数量不符",
  price_diff: "单价差异",
  duplicate: "重复记录",
  missing_left: "台账缺单",
  missing_right: "送货缺单",
};

function money(value) {
  return `¥${Number(value || 0).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function percent(value) {
  return Number.isInteger(value) ? `${value}%` : `${value.toFixed(1)}%`;
}

function keyOf(item) {
  return `${item.key.docNo}|${item.key.supplierCode}|${item.key.materialCode}`;
}

export function getExceptionReason(item) {
  if (item.reason && item.reason.trim()) return item.reason.trim();

  const firstLeft = item.left[0];
  const firstRight = item.right[0];
  switch (item.type) {
    case "qty_diff": {
      const difference = (firstRight?.qty || 0) - (firstLeft?.qty || 0);
      return `采购台账数量为 ${firstLeft?.qty ?? "—"}，供应商送货数量为 ${firstRight?.qty ?? "—"}，相差 ${difference > 0 ? "+" : ""}${difference}，请核实实际收货数量。`;
    }
    case "price_diff": {
      const difference = (firstRight?.unitPrice || 0) - (firstLeft?.unitPrice || 0);
      return `两侧未税单价分别为 ${money(firstLeft?.unitPrice)} 与 ${money(firstRight?.unitPrice)}，相差 ${difference >= 0 ? "+" : "−"}${money(Math.abs(difference))}，请核对合同或价格变更依据。`;
    }
    case "duplicate":
      return "同一匹配键下存在重复记录，请核对是否重复收货、重复录入或重复计账，并保留一条有效业务记录。";
    case "missing_left":
      return "仅供应商送货记录中存在该单据，采购台账无对应记录，请向采购确认并补齐台账。";
    case "missing_right":
      return "仅采购台账中存在该单据，供应商送货记录无对应记录，请向对方索取送货或结算凭证。";
    default:
      return "该记录未通过自动核对规则，请结合两侧原始记录人工复核。";
  }
}

// 摘要完全基于本地规则与完整结果计算，不调用任何模型。
export function buildSummary(result) {
  const items = result.items;
  const abnormalKeys = new Set(items.map(keyOf)).size;
  const totalKeys = result.totals.matchedKeys + abnormalKeys;
  const matchedKeys = result.totals.matchedKeys;
  const matchedRate = totalKeys ? (matchedKeys / totalKeys) * 100 : 100;
  const totalAmount = items.reduce((sum, item) => sum + item.amountImpact, 0);

  if (items.length === 0) {
    return {
      headline: `本次共核对 ${totalKeys.toLocaleString("zh-CN")} 个匹配键，全部一致（100%），未发现异常。`,
      bullets: [],
    };
  }

  const headline = `共核对 ${totalKeys.toLocaleString("zh-CN")} 个匹配键，一致 ${matchedKeys.toLocaleString("zh-CN")} 个（${percent(Math.round(matchedRate * 10) / 10)}），发现 ${items.length} 处异常，涉及金额 ${money(totalAmount)}。`;
  const typeCounts = countBy(items, (item) => item.type);
  const [topType, topTypeCount] = [...typeCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  const topItems = [...items]
    .sort((a, b) => b.amountImpact - a.amountImpact || a.key.docNo.localeCompare(b.key.docNo))
    .slice(0, 3)
    .map((item) => `${item.key.docNo} · ${item.materialName} ${money(item.amountImpact)}`)
    .join("；");
  const supplierCounts = countBy(items, (item) => item.key.supplierCode);
  const [topSupplier, topSupplierCount] = [...supplierCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  const supplierName = items.find((item) => item.key.supplierCode === topSupplier)?.supplierName || topSupplier;

  return {
    headline,
    bullets: [
      `异常类型以「${TYPE_LABELS[topType]}」最多，共 ${topTypeCount} 条，占全部异常的 ${percent(Math.round((topTypeCount / items.length) * 1000) / 10)}。`,
      `影响金额最高的 3 条：${topItems}。`,
      `异常最集中的供应商为「${supplierName}」，共 ${topSupplierCount} 条，建议优先与该供应商核对。`,
      buildAdvice(new Set(typeCounts.keys())),
    ],
  };
}

function countBy(items, getKey) {
  const counts = new Map();
  for (const item of items) {
    const key = getKey(item);
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return counts;
}

function buildAdvice(types) {
  const advice = [];
  if (types.has("duplicate")) advice.push("重复记录需确认是否重复计账");
  if (types.has("missing_left") || types.has("missing_right")) advice.push("缺单记录需及时向对应方补单");
  if (types.has("qty_diff")) advice.push("数量差异需结合实际收货与退换货记录复核");
  if (types.has("price_diff")) advice.push("单价差异需对照合同及有效调价凭证");
  return `处理建议：${advice.join("；")}。`;
}
