const VALID_TYPES = new Set(["qty_diff", "price_diff", "duplicate", "missing_left", "missing_right"]);

// 真实对账模块与页面结构之间的唯一转换层。
export function adaptResult(input) {
  if (!input || typeof input !== "object") fail("结果为空或不是对象");
  if (Array.isArray(input.items) && input.totals) return validatePageResult(input);
  if (Array.isArray(input.exceptions) && input.summary && Array.isArray(input.lines)) {
    return adaptReconcileResult(input);
  }
  fail("缺少 totals/items，或对账模块的 lines/exceptions/summary");
}

function validatePageResult(result) {
  for (const field of ["leftCount", "rightCount", "matchedKeys"]) {
    if (!Number.isFinite(result.totals[field]) || result.totals[field] < 0) {
      fail(`totals.${field} 应为非负数字`);
    }
  }

  result.items.forEach((item, index) => validateItem(item, index));
  return result;
}

function validateItem(item, index) {
  const prefix = `items[${index}]`;
  if (!item || typeof item !== "object") fail(`${prefix} 不是对象`);
  if (!item.id || !VALID_TYPES.has(item.type)) fail(`${prefix} 缺少有效 id 或异常类型`);
  if (!item.key || !item.key.docNo || !item.key.supplierCode || !item.key.materialCode) {
    fail(`${prefix}.key 必须包含单据编号、供应商编码和物料编码`);
  }
  if (!Number.isFinite(item.amountImpact) || item.amountImpact < 0) fail(`${prefix}.amountImpact 应为非负数字`);
  if (!Array.isArray(item.left) || !Array.isArray(item.right)) fail(`${prefix} 缺少两侧原始记录`);
  if (!Array.isArray(item.diffFields)) fail(`${prefix}.diffFields 应为数组`);
  [...item.left, ...item.right].forEach((record) => validateRecord(record, prefix));
}

function validateRecord(record, prefix) {
  const required = ["fileName", "rowIndex", "docNo", "supplierCode", "materialCode", "materialName", "qty", "unitPrice", "date"];
  if (!record || required.some((field) => record[field] == null || record[field] === "")) {
    fail(`${prefix} 存在字段不完整的原始记录`);
  }
}

function adaptReconcileResult(result) {
  const items = result.exceptions.map((exception, index) => {
    const left = (exception.purchaseRows || []).map((row) => adaptRecord(row, exception));
    const right = (exception.deliveryRows || []).map((row) => adaptRecord(row, exception));
    const type = adaptType(exception);
    const reference = left[0] || right[0] || {};

    return {
      id: String(exception.id || `exception-${index + 1}`),
      key: {
        docNo: exception.documentNo || reference.docNo,
        supplierCode: exception.supplierCode || reference.supplierCode,
        materialCode: exception.sku || reference.materialCode,
      },
      supplierName: exception.supplierName || reference.supplierName || exception.supplierCode || "未命名供应商",
      materialName: exception.materialName || reference.materialName || exception.sku || "未命名物料",
      type,
      amountImpact: calculateImpact(exception, type),
      diffFields: type === "qty_diff" ? ["qty"] : type === "price_diff" ? ["unitPrice"] : [],
      // 实际产生差异的那一对记录：多行同键时差额必须取自这里，
      // 而不是两侧首条，否则明细差额与差异说明、导出结果会互相矛盾。
      diffLeft: exception.purchase ? adaptRecord(exception.purchase, exception) : null,
      diffRight: exception.delivery ? adaptRecord(exception.delivery, exception) : null,
      left,
      right,
      reason: exception.message || "",
    };
  });

  const pageResult = {
    totals: {
      leftCount: result.summary.purchaseRowCount,
      rightCount: result.summary.deliveryRowCount,
      matchedKeys: result.summary.matchedKeyCount,
    },
    items,
  };
  return validatePageResult(pageResult);
}

function adaptRecord(row, exception) {
  return {
    fileName: row.fileName || "未命名文件",
    rowIndex: row.recordNumber ?? row.rowIndex,
    docNo: row.documentNo || exception.documentNo,
    supplierCode: row.supplierCode || exception.supplierCode,
    supplierName: row.supplierName || exception.supplierName || "",
    materialCode: row.sku || row.materialCode || exception.sku,
    materialName: row.materialName || exception.materialName || row.sku || row.materialCode || "未命名物料",
    qty: row.quantity ?? row.qty,
    unitPrice: row.unitPrice ?? ((row.unitPriceCents || 0) / 100),
    date: row.date || row.businessDate || "未提供日期",
  };
}

function adaptType(exception) {
  if (exception.type === "数量不符") return "qty_diff";
  if (exception.type === "单价差异") return "price_diff";
  if (exception.type === "重复计账") return "duplicate";
  if (exception.type === "缺单漏单") return exception.missingSide === "purchase" ? "missing_left" : "missing_right";
  fail(`无法识别异常类型「${exception.type}」`);
}

function calculateImpact(exception, type) {
  if (Number.isFinite(exception.amountImpact)) return Math.abs(exception.amountImpact);
  const purchase = exception.purchase;
  const delivery = exception.delivery;
  const price = ((purchase?.unitPriceCents ?? delivery?.unitPriceCents) || 0) / 100;
  const quantity = purchase?.quantity ?? delivery?.quantity ?? 0;

  if (type === "qty_diff") return Math.abs(exception.quantityDiff || 0) * price;
  if (type === "price_diff") return Math.abs(exception.priceDiffCents || 0) * quantity / 100;
  if (type === "duplicate") return sumRows(exception.duplicateRows || []);
  if (type.startsWith("missing_")) return sumRows(exception.missingRows || []);
  return 0;
}

function sumRows(rows) {
  return rows.reduce((sum, row) => sum + (row.quantity || 0) * ((row.unitPriceCents || 0) / 100), 0);
}

function fail(message) {
  throw new Error(`对账结果格式不正确：${message}`);
}
