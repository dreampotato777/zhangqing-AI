import { getExceptionReason } from "./summary.js";

const TYPE_LABELS = {
  qty_diff: "数量不符",
  price_diff: "单价差异",
  duplicate: "重复记录",
  missing_left: "台账缺单",
  missing_right: "送货缺单",
};

const HEADERS = [
  "异常类型", "单据编号", "供应商编码", "供应商名称", "物料编码", "物料名称",
  "台账数量", "送货数量", "数量差", "台账单价", "送货单价", "单价差",
  "影响金额", "台账来源（文件名:行号）", "送货来源（文件名:行号）", "差异说明",
];

function csvCell(value, isText = false) {
  let text = value == null ? "" : String(value);
  // 仅文本字段需要防止 Excel 将内容解释为公式。
  if (isText && /^[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

function joinedValues(records, field) {
  if (records.length <= 1) return records[0]?.[field] ?? "";
  return records.map((record) => record[field]).join("；");
}

function sources(records) {
  return records.map((record) => `${record.fileName}:${record.rowIndex}`).join("；");
}

// 差额取自实际产生差异的那一对记录（diffLeft / diffRight）；
// 旧页面结构没有这两个字段时，退回两侧仅有一条记录的情况。
function diffRecord(item, side) {
  const paired = side === "left" ? item.diffLeft : item.diffRight;
  if (paired) return paired;
  const rows = item[side] || [];
  return rows.length === 1 ? rows[0] : null;
}

function difference(item, field) {
  const left = diffRecord(item, "left");
  const right = diffRecord(item, "right");
  if (!left || !right || left[field] == null || right[field] == null) return "";
  return Number((right[field] - left[field]).toFixed(2));
}

export function buildDiffCsv(items) {
  const rows = items.map((item) => [
    csvCell(TYPE_LABELS[item.type] || item.type, true),
    csvCell(item.key.docNo, true),
    csvCell(item.key.supplierCode, true),
    csvCell(item.supplierName, true),
    csvCell(item.key.materialCode, true),
    csvCell(item.materialName, true),
    csvCell(joinedValues(item.left, "qty")),
    csvCell(joinedValues(item.right, "qty")),
    csvCell(difference(item, "qty")),
    csvCell(joinedValues(item.left, "unitPrice")),
    csvCell(joinedValues(item.right, "unitPrice")),
    csvCell(difference(item, "unitPrice")),
    csvCell(item.amountImpact),
    csvCell(sources(item.left), true),
    csvCell(sources(item.right), true),
    csvCell(getExceptionReason(item), true),
  ]);

  // BOM 让 Excel 按 UTF-8 识别中文；所有单元格统一按 CSV 规则转义。
  return `\uFEFF${HEADERS.map((header) => csvCell(header, true)).join(",")}\r\n${rows.map((row) => row.join(",")).join("\r\n")}`;
}

export function downloadCsv(filename, text) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}
