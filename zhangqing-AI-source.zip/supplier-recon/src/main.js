// 页面入口（D）：把 A 的 CSV 读取、B 的对账规则与 C 的页面报告串起来。
// 统计、筛选、两侧原始记录、摘要和 CSV 导出都来自同一次 reconcile 的实际输出。

// A：CSV 读取（不改）
import { parseCsv, readCsvFile } from "./csv.js";
// B：对账规则（不改）
import { reconcile } from "./reconcile.js";
// C：页面与报告
import { mountReport, updateReport } from "./ui/mountReport.js";
// C：下载工具（与差异 CSV 导出同一套实现）
import { downloadCsv } from "./report/exportCsv.js";

// 模拟数据走与真实导入完全相同的解析、核对和转换链路。
import purchaseDemoCsv from "./data/purchase-demo.csv?raw";
import deliveryDemoCsv from "./data/delivery-demo.csv?raw";
// 空白模板：保留原表头，另取一条样例记录作为示例行；原模板文件不动。
import templateCsv from "./data/template.csv?raw";
// 路演示例数据：评委可直接下载后分别传入两个上传框跑通核对。
import purchaseRoadshowCsv from "./data/采购台账_路演.csv?raw";
import deliveryRoadshowCsv from "./data/供应商送货_路演.csv?raw";

const SAMPLE_ROW = "D001,S001,M01,10,12.50";

const rootEl = document.querySelector("#report-root");
const purchaseInput = document.querySelector("#purchase-file");
const deliveryInput = document.querySelector("#delivery-file");
const importButton = document.querySelector("#import-button");
const demoButton = document.querySelector("#demo-button");
const errorEl = document.querySelector("#import-error");
const downloadTemplateButton = document.querySelector("#download-template");
const downloadSampleButton = document.querySelector("#download-sample");

const slots = {
  purchase: {
    input: purchaseInput,
    statusEl: document.querySelector("#purchase-status"),
    errorEl: document.querySelector("#purchase-error"),
    label: "采购台账",
    file: null,
    valid: false,
  },
  delivery: {
    input: deliveryInput,
    statusEl: document.querySelector("#delivery-status"),
    errorEl: document.querySelector("#delivery-error"),
    label: "供应商送货",
    file: null,
    valid: false,
  },
};

let hasMounted = false;
let busy = false;

function renderResult(result, source) {
  if (!hasMounted) {
    mountReport(rootEl, { result, source });
    hasMounted = true;
  } else {
    updateReport({ result, source });
  }
}

function showError(message) {
  errorEl.textContent = message;
}

function formatParseErrors(errors) {
  return errors
    .map((error) => {
      const row = error.recordNumber == null ? "" : `，第 ${error.recordNumber} 行`;
      return `${error.fileName}${row}：${error.message}`;
    })
    .join("\n");
}

// 单框错误汇总：表头缺列时聚合成「XX（文件名）缺少列：A、B」，其余错误逐条展示。
function describeSlotErrors(side, errors) {
  const slot = slots[side];
  const fileName = slot.file?.name ?? "未命名文件";
  const missingColumns = [];
  const otherLines = [];
  for (const error of errors) {
    const match = /^表头缺少必需列「(.+?)」$/.exec(error.message);
    if (match) {
      missingColumns.push(match[1]);
    } else {
      const row = error.recordNumber == null ? "" : `，第 ${error.recordNumber} 行`;
      otherLines.push(`${error.fileName}${row}：${error.message}`);
    }
  }
  const lines = [];
  if (missingColumns.length > 0) {
    lines.push(`${slot.label}（${fileName}）缺少列：${missingColumns.join("、")}`);
  }
  lines.push(...otherLines);
  return lines.join("\n");
}

function renderSlot(side) {
  const slot = slots[side];
  if (slot.file) {
    slot.statusEl.textContent = `已选择：${slot.file.name}`;
    slot.statusEl.classList.toggle("ok", slot.valid);
  } else {
    slot.statusEl.textContent = "尚未选择文件";
    slot.statusEl.classList.remove("ok");
  }
  slot.errorEl.textContent = slot.errorMessage ?? "";
}

function updateImportButton() {
  importButton.disabled = busy || !(slots.purchase.valid && slots.delivery.valid);
}

function setBusy(next) {
  busy = next;
  demoButton.disabled = busy;
  importButton.textContent = busy ? "核对中…" : "导入并核对";
  updateImportButton();
}

// 选档后立即按同一套解析器校验，错误只落在对应框下方。
async function validateSlot(side) {
  const slot = slots[side];
  slot.file = slot.input.files?.[0] ?? null;
  slot.valid = false;
  slot.errorMessage = null;

  if (!slot.file) {
    renderSlot(side);
    updateImportButton();
    return;
  }

  // 解析是异步的，先显示文件名再等结果。
  slot.statusEl.textContent = `已选择：${slot.file.name}`;
  const result = await readCsvFile(slot.file);
  if (result.ok) {
    slot.valid = true;
  } else {
    slot.errorMessage = describeSlotErrors(side, result.errors);
  }
  renderSlot(side);
  updateImportButton();
}

async function importFiles() {
  const purchaseFile = slots.purchase.file;
  const deliveryFile = slots.delivery.file;

  if (!purchaseFile || !deliveryFile) {
    showError("请先选择采购台账和供应商送货记录两个 CSV 文件。");
    return;
  }

  setBusy(true);
  showError("");

  try {
    // 提交前仍走现有完整校验（表头 + 全部数据行），错误分别落到对应上传框下方。
    const [purchaseParsed, deliveryParsed] = await Promise.all([
      readCsvFile(purchaseFile),
      readCsvFile(deliveryFile),
    ]);

    const purchaseFailed = !purchaseParsed.ok;
    const deliveryFailed = !deliveryParsed.ok;
    if (purchaseFailed || deliveryFailed) {
      slots.purchase.errorMessage = purchaseFailed
        ? describeSlotErrors("purchase", purchaseParsed.errors)
        : null;
      slots.delivery.errorMessage = deliveryFailed
        ? describeSlotErrors("delivery", deliveryParsed.errors)
        : null;
      renderSlot("purchase");
      renderSlot("delivery");
      showError("");
      return;
    }

    // B 的真实输出：{ lines, exceptions, summary }
    const reconcileOutput = reconcile(purchaseParsed.rows, deliveryParsed.rows);

    renderResult(reconcileOutput, {
      label: "本地文件",
      files: [purchaseFile.name, deliveryFile.name],
    });
  } catch (error) {
    // 失败时保留上一份已成功展示的结果，只在导入区提示。
    showError(error instanceof Error ? error.message : "文件导入或核对失败，请检查文件后重试。");
  } finally {
    setBusy(false);
  }
}

function loadDemo() {
  setBusy(true);
  showError("");
  try {
    const purchaseParsed = parseCsv(purchaseDemoCsv, "purchase-demo.csv");
    const deliveryParsed = parseCsv(deliveryDemoCsv, "delivery-demo.csv");

    const parseErrors = [
      ...(purchaseParsed.ok ? [] : purchaseParsed.errors),
      ...(deliveryParsed.ok ? [] : deliveryParsed.errors),
    ];
    if (parseErrors.length > 0) throw new Error(formatParseErrors(parseErrors));

    renderResult(reconcile(purchaseParsed.rows, deliveryParsed.rows), {
      label: "模拟数据",
      files: ["purchase-demo.csv", "delivery-demo.csv"],
    });
  } catch (error) {
    showError(error instanceof Error ? error.message : "模拟数据载入失败，请稍后重试。");
  } finally {
    setBusy(false);
  }
}

// 下载件统一带 UTF-8 BOM，方便 Excel 直接打开且不影响解析（解析器会剥离 BOM）。
function downloadTextFile(fileName, text) {
  downloadCsv(fileName, `\uFEFF${text}`);
}

// 空白模板：保留原表头 + 一条有效示例行；src/data/template.csv 本身保持原样。
downloadTemplateButton.addEventListener("click", () => {
  const header = templateCsv.replace(/^\uFEFF/, "").split(/\r?\n/)[0];
  downloadTextFile("template.csv", `${header}\r\n${SAMPLE_ROW}`);
});

// 示例数据：一个入口分别下载两份路演 CSV，可分别传入两个上传框直接核对。
downloadSampleButton.addEventListener("click", () => {
  downloadTextFile("采购台账_路演.csv", purchaseRoadshowCsv.replace(/^\uFEFF/, ""));
  downloadTextFile("供应商送货_路演.csv", deliveryRoadshowCsv.replace(/^\uFEFF/, ""));
});

importButton.addEventListener("click", importFiles);
demoButton.addEventListener("click", loadDemo);
purchaseInput.addEventListener("change", () => validateSlot("purchase"));
deliveryInput.addEventListener("change", () => validateSlot("delivery"));

// 初始状态：导入按钮按当前条件（两份文件均通过校验）保持禁用。
updateImportButton();
