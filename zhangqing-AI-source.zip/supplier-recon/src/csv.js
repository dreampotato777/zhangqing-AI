/**
 * CSV 读取与校验。
 *
 * 只负责把 CSV 文本变成统一结构的记录，不做去重，也不做对账判断。
 * B 负责基于 source/fileName 与重复记录做对账；D 负责页面入口。
 */

const REQUIRED_COLUMNS = ["单据编号", "供应商编码", "物料编码", "数量", "未税单价"];
const DEFAULT_FILE_NAME = "未命名文件";

/**
 * 解析 CSV 文本。
 *
 * @param {string} text CSV 原文
 * @param {string} [fileName] 来源文件名，会原样写入每条记录和错误
 * @returns {{ ok: true, rows: Array<object> } | { ok: false, errors: Array<{fileName: string, recordNumber: number|null, message: string}> }}
 */
export function parseCsv(text, fileName = DEFAULT_FILE_NAME) {
  const name = typeof fileName === "string" && fileName.trim() ? fileName : DEFAULT_FILE_NAME;

  if (typeof text !== "string") {
    return failure(name, null, "文件内容不是文本，无法解析");
  }

  // 兼容 Excel 等工具导出的 UTF-8 BOM。
  const source = text.replace(/^\uFEFF/, "");
  if (source.trim() === "") {
    return failure(name, null, "文件为空，未找到表头");
  }

  let records;
  try {
    records = parseRecords(source);
  } catch (error) {
    return failure(name, null, `CSV 格式错误：${error.message}`);
  }

  const headerRecord = records[0];
  const header = headerRecord.values.map((cell) => cell.replace(/^\uFEFF/, "").trim());

  // 必需列可以换顺序，但 5 列必须齐全且不能重复。
  const headerErrors = [];
  for (const column of REQUIRED_COLUMNS) {
    const count = header.filter((cell) => cell === column).length;
    if (count === 0) {
      headerErrors.push(`表头缺少必需列「${column}」`);
    } else if (count > 1) {
      headerErrors.push(`表头中「${column}」重复出现，无法确定取值列`);
    }
  }
  if (headerErrors.length > 0) {
    return {
      ok: false,
      errors: headerErrors.map((message) => ({
        fileName: name,
        recordNumber: headerRecord.recordNumber,
        message,
      })),
    };
  }

  const columnIndex = {};
  for (const column of REQUIRED_COLUMNS) {
    columnIndex[column] = header.indexOf(column);
  }

  // 纯空行跳过；表头之后的记录按 CSV 逻辑记录序号保留，不重新编号。
  const dataRecords = records
    .slice(1)
    .filter((record) => !isBlankRecord(record.values));

  if (dataRecords.length === 0) {
    return failure(name, null, "文件没有数据行，只有表头或空行");
  }

  const rows = [];
  const errors = [];

  for (const record of dataRecords) {
    const { values, recordNumber } = record;

    if (values.length !== header.length) {
      errors.push({
        fileName: name,
        recordNumber,
        message: `列数不符：表头有 ${header.length} 列，本行有 ${values.length} 列`,
      });
      continue;
    }

    const read = (column) => (values[columnIndex[column]] ?? "").trim();

    const documentNo = read("单据编号");
    const supplierCode = read("供应商编码");
    const sku = read("物料编码");
    const quantityText = read("数量");
    const unitPriceText = read("未税单价");

    const rowErrors = [];
    if (documentNo === "") rowErrors.push("单据编号不能为空");
    if (supplierCode === "") rowErrors.push("供应商编码不能为空");
    if (sku === "") rowErrors.push("物料编码不能为空");

    const quantity = parseQuantity(quantityText);
    if (quantity.error) rowErrors.push(quantity.error);

    const unitPrice = parseUnitPrice(unitPriceText);
    if (unitPrice.error) rowErrors.push(unitPrice.error);

    if (rowErrors.length > 0) {
      for (const message of rowErrors) {
        errors.push({ fileName: name, recordNumber, message });
      }
      continue;
    }

    rows.push({
      documentNo,
      supplierCode,
      sku,
      quantity: quantity.value,
      unitPriceCents: unitPrice.value,
      fileName: name,
      recordNumber,
    });
  }

  // 只要有一条记录不合法，整份文件导入失败，避免残缺数据流入对账。
  if (errors.length > 0) {
    return { ok: false, errors };
  }

  return { ok: true, rows };
}

/**
 * 读取浏览器文件选择框返回的 File。
 * 严格按 UTF-8 解码，解码失败视为文件级错误。
 *
 * @param {File} file
 * @returns {Promise<{ ok: true, rows: Array<object> } | { ok: false, errors: Array<object> }>}
 */
export async function readCsvFile(file) {
  const fileName =
    file && typeof file.name === "string" && file.name ? file.name : DEFAULT_FILE_NAME;

  if (!file || typeof file.arrayBuffer !== "function") {
    return failure(fileName, null, "未选择文件或文件对象无效");
  }

  let buffer;
  try {
    buffer = await file.arrayBuffer();
  } catch {
    return failure(fileName, null, "无法读取文件内容，请重新选择文件");
  }

  let text;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(buffer);
  } catch {
    return failure(fileName, null, "文件不是有效的 UTF-8 编码，请另存为 UTF-8 后重试");
  }

  return parseCsv(text, fileName);
}

function failure(fileName, recordNumber, message) {
  return { ok: false, errors: [{ fileName, recordNumber, message }] };
}

function isBlankRecord(values) {
  return values.length === 1 && values[0].trim() === "";
}

function parseQuantity(raw) {
  if (raw === "") return { error: "数量不能为空" };
  if (!/^\d+$/.test(raw)) return { error: `数量「${raw}」不是正整数` };

  const value = Number(raw);
  if (!Number.isSafeInteger(value)) {
    return { error: `数量「${raw}」超出可处理范围` };
  }
  if (value <= 0) {
    return { error: `数量「${raw}」必须大于 0` };
  }
  return { value };
}

function parseUnitPrice(raw) {
  if (raw === "") return { error: "未税单价不能为空" };
  if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) {
    return { error: `未税单价「${raw}」格式不正确，应为非负金额且最多两位小数` };
  }

  // 直接按文本拆分整数与小数部分，避免浮点误差。
  const [integerPart, fractionPart = ""] = raw.split(".");
  const value = Number(integerPart) * 100 + Number(fractionPart.padEnd(2, "0"));

  if (!Number.isSafeInteger(value)) {
    return { error: `未税单价「${raw}」超出可处理范围` };
  }
  return { value };
}

/**
 * RFC 4180 风格解析：支持引号包裹的逗号、换行，以及 "" 转义。
 * 返回逻辑记录及其从 1 开始的序号（表头为第 1 条）。
 */
function parseRecords(source) {
  const records = [];
  let values = [];
  let field = "";
  // start | unquoted | quoted | afterQuote
  let state = "start";
  let recordNumber = 1;
  let index = 0;

  const endField = () => {
    values.push(field);
    field = "";
    state = "start";
  };

  const endRecord = () => {
    endField();
    records.push({ values, recordNumber });
    values = [];
    recordNumber += 1;
  };

  while (index < source.length) {
    const char = source[index];

    if (state === "quoted") {
      if (char === '"') {
        if (source[index + 1] === '"') {
          field += '"';
          index += 2;
        } else {
          state = "afterQuote";
          index += 1;
        }
      } else {
        field += char;
        index += 1;
      }
      continue;
    }

    if (state === "afterQuote") {
      if (char === ",") {
        endField();
        index += 1;
        continue;
      }
      if (char === "\r") {
        if (source[index + 1] === "\n") index += 1;
        endRecord();
        index += 1;
        continue;
      }
      if (char === "\n") {
        endRecord();
        index += 1;
        continue;
      }
      if (char === " " || char === "\t") {
        index += 1;
        continue;
      }
      throw new Error(
        `第 ${recordNumber} 条记录在引号结束后出现多余字符「${char}」`
      );
    }

    if (char === '"') {
      if (state === "start") {
        state = "quoted";
        index += 1;
        continue;
      }
      throw new Error(
        `第 ${recordNumber} 条记录中引号位置不正确，字段内双引号请用 "" 转义`
      );
    }

    if (char === ",") {
      endField();
      index += 1;
      continue;
    }

    if (char === "\r") {
      if (source[index + 1] === "\n") index += 1;
      endRecord();
      index += 1;
      continue;
    }

    if (char === "\n") {
      endRecord();
      index += 1;
      continue;
    }

    field += char;
    state = "unquoted";
    index += 1;
  }

  if (state === "quoted") {
    throw new Error(`第 ${recordNumber} 条记录引号未闭合`);
  }

  if (state === "afterQuote" || state === "unquoted" || values.length > 0) {
    endRecord();
  }

  return records;
}
