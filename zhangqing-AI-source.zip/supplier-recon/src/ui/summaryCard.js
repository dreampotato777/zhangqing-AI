import { buildSummary } from "../report/summary.js";
import { icon } from "./constants.js";
import { escapeHtml } from "./format.js";

export function renderSummaryCard(result) {
  const summary = buildSummary(result);
  return `<section class="summary-card" aria-labelledby="summary-title">
    <div class="summary-heading">
      <div class="summary-title-wrap">
        <span class="summary-symbol">${icon("file")}</span>
        <div><h2 id="summary-title">对账摘要</h2><p>基于完整核对结果，不随列表筛选变化</p></div>
      </div>
      <div class="summary-actions">
        <span class="rule-badge">规则自动生成 · 非大模型</span>
        <button type="button" class="button button-quiet button-small" data-action="copy-summary">${icon("copy")}复制摘要</button>
        <button type="button" class="icon-button collapse-button" data-action="toggle-summary" aria-expanded="true" aria-controls="summary-body" title="折叠摘要">${icon("chevron")}<span class="sr-only">折叠摘要</span></button>
      </div>
    </div>
    <div class="summary-body" id="summary-body">
      <p class="summary-headline">${escapeHtml(summary.headline)}</p>
      ${summary.bullets.length ? `<ol class="summary-bullets">${summary.bullets.map((bullet) => `<li>${escapeHtml(bullet)}</li>`).join("")}</ol>` : ""}
    </div>
  </section>`;
}
