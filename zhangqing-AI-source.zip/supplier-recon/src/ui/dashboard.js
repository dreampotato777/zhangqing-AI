import { TYPE_META, TYPE_ORDER } from "./constants.js";
import { escapeHtml, formatMoney, formatNumber, formatPercent } from "./format.js";

export function renderDashboard(result) {
  const { totals, items } = result;
  const abnormalKeys = new Set(items.map((item) => `${item.key.docNo}|${item.key.supplierCode}|${item.key.materialCode}`)).size;
  const totalKeys = totals.matchedKeys + abnormalKeys;
  const matchedRate = totalKeys ? (totals.matchedKeys / totalKeys) * 100 : 100;
  const amount = items.reduce((sum, item) => sum + item.amountImpact, 0);
  const counts = Object.fromEntries(TYPE_ORDER.map((type) => [type, items.filter((item) => item.type === type).length]));

  return `<section class="stats-grid" aria-label="对账统计看板">
    ${statCard("核对键总数", totalKeys, "integer", `台账 ${formatNumber(totals.leftCount)} 行 · 送货 ${formatNumber(totals.rightCount)} 行`, "按单据 + 供应商 + 物料匹配")}
    ${statCard("完全一致率", matchedRate, "percent", `${formatNumber(totals.matchedKeys)} 个键无需处理`, "仅统计数量与单价完全一致")}
    ${statCard("异常总数", items.length, "integer", `${abnormalKeys} 个匹配键需复核`, items.length ? "建议优先查看高金额异常" : "本次核对全部通过")}
    ${statCard("涉及金额合计", amount, "money", "按差异影响金额绝对值汇总", "用于确定复核优先级")}
    <article class="stat-card distribution-card">
      <div class="stat-card-head"><span>异常类型分布</span><span class="stat-total">${items.length} 条</span></div>
      <div class="distribution-bar" role="img" aria-label="${escapeHtml(TYPE_ORDER.map((type) => `${TYPE_META[type].label} ${counts[type]} 条`).join("，"))}">
        ${items.length ? TYPE_ORDER.filter((type) => counts[type] > 0).map((type) => `<span class="distribution-segment" style="--segment-color:${TYPE_META[type].color};width:${(counts[type] / items.length) * 100}%" title="${TYPE_META[type].label} ${counts[type]} 条"><b>${counts[type]}</b></span>`).join("") : '<span class="distribution-empty">无异常</span>'}
      </div>
      <div class="distribution-legend">
        ${TYPE_ORDER.map((type) => `<span title="${TYPE_META[type].label} ${counts[type]} 条"><i style="--legend-color:${TYPE_META[type].color}"></i>${TYPE_META[type].label}<b>${counts[type]}</b></span>`).join("")}
      </div>
    </article>
  </section>`;
}

function statCard(label, value, format, primaryHint, secondaryHint) {
  const display = format === "money" ? formatMoney(value) : format === "percent" ? formatPercent(value) : formatNumber(value, 0);
  return `<article class="stat-card">
    <div class="stat-card-head"><span>${label}</span><span class="stat-kicker">本次</span></div>
    <strong class="stat-value ${format === "money" ? "stat-money" : ""}" data-animate-number data-value="${value}" data-format="${format}">${display}</strong>
    <div class="stat-primary-hint" title="${escapeHtml(primaryHint)}">${escapeHtml(primaryHint)}</div>
    <div class="stat-secondary-hint">${escapeHtml(secondaryHint)}</div>
  </article>`;
}
