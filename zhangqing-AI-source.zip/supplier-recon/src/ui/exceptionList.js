import { icon } from "./constants.js";
import { escapeHtml, formatMoney, typeBadge } from "./format.js";
import { renderState } from "./stateView.js";

export function renderExceptionList({ items, total, selectedId }) {
  return `<section class="exception-list" aria-label="异常清单">
    <div class="list-heading">
      <div><h2>异常清单</h2><span>当前 ${items.length} / ${total} 条</span></div>
      <span class="keyboard-hint" title="在列表中使用上下方向键切换">${icon("keyboard")}↑ ↓ 切换</span>
    </div>
    <div class="exception-rows" data-exception-list role="listbox" aria-label="选择要查看的异常">
      ${items.length ? items.map((item) => renderRow(item, item.id === selectedId)).join("") : renderState("empty")}
    </div>
  </section>`;
}

function renderRow(item, selected) {
  const fullName = `${item.materialName} · ${item.supplierName}`;
  return `<button type="button" class="exception-row ${selected ? "is-selected" : ""}" data-action="select-item" data-id="${escapeHtml(item.id)}" data-focus-key="item-${escapeHtml(item.id)}" role="option" aria-selected="${selected}" tabindex="${selected ? "0" : "-1"}">
    <span class="exception-row-top">${typeBadge(item.type)}<strong class="exception-doc" title="${escapeHtml(item.key.docNo)}">${escapeHtml(item.key.docNo)}</strong><strong class="exception-amount">${formatMoney(item.amountImpact)}</strong></span>
    <span class="exception-row-bottom"><strong title="${escapeHtml(fullName)}">${escapeHtml(item.materialName)}</strong><span title="${escapeHtml(item.supplierName)}">${escapeHtml(item.supplierName)}</span></span>
  </button>`;
}
