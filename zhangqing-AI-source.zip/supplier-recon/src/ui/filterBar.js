import { TYPE_META, TYPE_ORDER, icon } from "./constants.js";
import { escapeHtml } from "./format.js";

export function renderFilterBar(result, filters) {
  const suppliers = new Map();
  for (const item of result.items) {
    suppliers.set(item.key.supplierCode, item.supplierName);
  }

  return `<div class="filter-bar" aria-label="异常筛选">
    <div class="filter-topline"><span>${icon("filter")}筛选异常</span><button type="button" class="text-button" data-action="clear-filters" data-focus-key="clear">清除筛选</button></div>
    <div class="type-chips" aria-label="按异常类型多选">
      ${TYPE_ORDER.map((type) => {
        const count = result.items.filter((item) => item.type === type).length;
        const active = filters.types.has(type);
        return `<button type="button" class="type-chip ${active ? "is-active" : ""}" style="--type-color:${TYPE_META[type].color};--type-bg:${TYPE_META[type].background}" data-action="filter-type" data-type="${type}" data-focus-key="type-${type}" aria-pressed="${active}" title="筛选${TYPE_META[type].label}"><i></i>${TYPE_META[type].label}<b>${count}</b></button>`;
      }).join("")}
    </div>
    <div class="filter-controls">
      <label class="select-control"><span class="sr-only">供应商</span><select data-filter="supplier" data-focus-key="supplier" title="按供应商筛选">
        <option value="">全部供应商</option>
        ${[...suppliers.entries()].map(([code, name]) => `<option value="${escapeHtml(code)}" ${filters.supplier === code ? "selected" : ""}>${escapeHtml(name)}（${code}）</option>`).join("")}
      </select>${icon("chevron")}</label>
      <label class="search-control">${icon("search")}<span class="sr-only">搜索单据号、物料编码或物料名称</span><input type="search" data-filter="query" data-focus-key="query" value="${escapeHtml(filters.query)}" placeholder="单据号 / 物料编码 / 名称" autocomplete="off"></label>
      <label class="select-control sort-control"><span class="sr-only">排序方式</span><select data-filter="sort" data-focus-key="sort" title="异常排序">
        <option value="amount" ${filters.sort === "amount" ? "selected" : ""}>按影响金额↓</option>
        <option value="docNo" ${filters.sort === "docNo" ? "selected" : ""}>按单据号</option>
      </select>${icon("chevron")}</label>
    </div>
  </div>`;
}
