import "../styles/report.css";
import { adaptResult } from "../report/adapter.js";
import { buildDiffCsv, downloadCsv } from "../report/exportCsv.js";
import { buildSummary } from "../report/summary.js";
import { renderDashboard } from "./dashboard.js";
import { renderDetail } from "./detailComparison.js";
import { renderExceptionList } from "./exceptionList.js";
import { renderFilterBar } from "./filterBar.js";
import { icon } from "./constants.js";
import { escapeHtml, formatMoney, formatNumber, formatPercent } from "./format.js";
import { renderState } from "./stateView.js";
import { renderSummaryCard } from "./summaryCard.js";

let session = null;

export function mountReport(rootEl, { result, source } = {}) {
  if (!rootEl || rootEl.nodeType !== 1) throw new Error("mountReport 需要有效的根元素");
  if (session?.abort) session.abort.abort();

  const abort = new AbortController();
  session = {
    root: rootEl,
    result: null,
    source: normalizeSource(source),
    filtered: [],
    selectedId: null,
    filters: createFilters(),
    abort,
    animationFrame: null,
    toastTimer: null,
  };

  const options = { signal: abort.signal };
  rootEl.addEventListener("click", handleClick, options);
  rootEl.addEventListener("input", handleInput, options);
  rootEl.addEventListener("change", handleChange, options);
  rootEl.addEventListener("keydown", handleKeydown, options);
  loadResult(result, session.source);
}

export function updateReport({ result, source } = {}) {
  if (!session) throw new Error("请先调用 mountReport 完成首次渲染");
  loadResult(result, normalizeSource(source || session.source));
}

function loadResult(input, source) {
  if (session.animationFrame) cancelAnimationFrame(session.animationFrame);
  session.source = source;
  try {
    session.result = adaptResult(input);
    session.filters = createFilters();
    session.selectedId = null;
    renderShell();
    applyFilters();
    renderDynamic({ withFilter: true, resetScroll: true });
    animateNumbers();
  } catch (error) {
    session.result = null;
    session.filtered = [];
    session.selectedId = null;
    renderError(error instanceof Error ? error.message : "请检查数据结构后重试。 ");
  }
}

function renderShell() {
  const { root, result } = session;
  root.classList.add("report-app");
  root.innerHTML = `${renderHeader()}
    <div class="report-content">
      ${renderDashboard(result)}
      ${renderSummaryCard(result)}
      <main class="report-main">
        ${result.items.length ? `<div class="workspace">
          <div class="exception-panel">
            <div data-filter-region></div>
            <div data-list-region></div>
          </div>
          <div data-detail-region class="detail-region"></div>
        </div>` : `<section class="report-state-card">${renderState("success")}</section>`}
      </main>
      <footer class="report-footer"><span>本地规则核对</span><i></i><span>保留原始文件与行号</span><i></i><span>数据不出当前浏览器</span></footer>
    </div>
    <div class="report-toast" data-toast aria-live="polite" aria-atomic="true"></div>`;
}

function renderHeader() {
  const { source } = session;
  const files = source.files.filter(Boolean);
  const sourceText = source.label === "本地文件"
    ? `本地文件${files.length ? `：${files.join(" + ")}` : ""}`
    : `${source.label || "模拟数据"} · 仅用于演示`;
  return `<header class="report-topbar">
    <div class="report-brand">
      <svg class="brand-mark" viewBox="0 0 36 36" fill="none" aria-hidden="true"><rect x="1" y="1" width="34" height="34" rx="10" fill="currentColor"/><path d="M10 12.5h16M10 18h10M10 23.5h7" stroke="white" stroke-width="2.2" stroke-linecap="round"/><path d="m20 23 2.2 2.2L27.5 20" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div><div class="brand-name">账清AI</div><p>供应商物料往来对账</p></div>
    </div>
    <div class="topbar-actions">
      <span class="source-badge" title="${escapeHtml(sourceText)}">${icon(source.label === "本地文件" ? "file" : "check")}<span>${escapeHtml(sourceText)}</span></span>
      <button type="button" class="button button-primary export-button" data-action="export" data-export-button disabled>${icon("download")}<span data-export-label>导出差异 CSV（0 条）</span></button>
    </div>
  </header>`;
}

function renderError(message) {
  const { root } = session;
  root.classList.add("report-app");
  root.innerHTML = `${renderHeader()}<div class="report-content"><main class="report-main"><section class="report-state-card error-state-card">${renderState("error", message)}<p class="error-help">需要包含 totals、items，并保留每条异常的 left/right 原始记录。</p></section></main></div><div class="report-toast" data-toast aria-live="polite"></div>`;
  updateExportButton();
}

function renderDynamic({ withFilter = false, resetScroll = false, focusSelected = false, focusKey = "" } = {}) {
  const { root, result, filters, filtered, selectedId } = session;
  if (!result) return;
  const focus = captureFocus();
  const previousScroll = root.querySelector(".exception-rows")?.scrollTop || 0;

  if (withFilter) {
    const filterRegion = root.querySelector("[data-filter-region]");
    if (filterRegion) filterRegion.innerHTML = renderFilterBar(result, filters);
  }
  const listRegion = root.querySelector("[data-list-region]");
  const detailRegion = root.querySelector("[data-detail-region]");
  if (listRegion) listRegion.innerHTML = renderExceptionList({ items: filtered, total: result.items.length, selectedId });
  if (detailRegion) {
    detailRegion.innerHTML = renderDetail(filtered.find((item) => item.id === selectedId));
    detailRegion.scrollTop = 0;
  }
  updateExportButton();

  const rows = root.querySelector(".exception-rows");
  if (rows) rows.scrollTop = resetScroll ? 0 : previousScroll;
  if (focusSelected) focusSelectedRow();
  else if (focusKey) focusByKey(focusKey);
  else restoreFocus(focus);
}

function applyFilters() {
  const { result, filters } = session;
  const query = filters.query.trim().toLocaleLowerCase("zh-CN");
  const items = result.items.filter((item) => {
    if (filters.types.size && !filters.types.has(item.type)) return false;
    if (filters.supplier && item.key.supplierCode !== filters.supplier) return false;
    if (query) {
      const haystack = `${item.key.docNo} ${item.key.materialCode} ${item.materialName}`.toLocaleLowerCase("zh-CN");
      if (!haystack.includes(query)) return false;
    }
    return true;
  });

  items.sort(filters.sort === "docNo"
    ? (a, b) => a.key.docNo.localeCompare(b.key.docNo, "zh-CN", { numeric: true }) || a.id.localeCompare(b.id)
    : (a, b) => b.amountImpact - a.amountImpact || a.key.docNo.localeCompare(b.key.docNo, "zh-CN", { numeric: true }));
  session.filtered = items;
  // 数据或筛选条件变化后始终回到当前结果第一条，避免右侧保留旧焦点。
  session.selectedId = items[0]?.id || null;
}

function handleClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button || !session.root.contains(button)) return;
  const action = button.dataset.action;

  if (action === "filter-type") {
    const type = button.dataset.type;
    if (session.filters.types.has(type)) session.filters.types.delete(type);
    else session.filters.types.add(type);
    applyFilters();
    renderDynamic({ withFilter: true, resetScroll: true });
  } else if (action === "clear-filters") {
    session.filters = createFilters();
    applyFilters();
    renderDynamic({ withFilter: true, resetScroll: true, focusKey: "query" });
  } else if (action === "select-item") {
    selectItem(button.dataset.id, false);
  } else if (action === "export") {
    exportCurrentItems();
  } else if (action === "copy-summary") {
    void copySummary();
  } else if (action === "toggle-summary") {
    toggleSummary(button);
  }
}

function handleInput(event) {
  if (event.target.dataset.filter !== "query" || !session.result) return;
  session.filters.query = event.target.value;
  applyFilters();
  renderDynamic({ resetScroll: true });
}

function handleChange(event) {
  const filter = event.target.dataset.filter;
  if (!session.result || !["supplier", "sort"].includes(filter)) return;
  session.filters[filter] = event.target.value;
  applyFilters();
  renderDynamic({ resetScroll: true });
}

function handleKeydown(event) {
  if (!["ArrowUp", "ArrowDown"].includes(event.key) || !event.target.closest(".exception-row")) return;
  event.preventDefault();
  const currentIndex = session.filtered.findIndex((item) => item.id === session.selectedId);
  const offset = event.key === "ArrowDown" ? 1 : -1;
  const nextIndex = Math.max(0, Math.min(session.filtered.length - 1, currentIndex + offset));
  const next = session.filtered[nextIndex];
  if (next) selectItem(next.id, true);
}

function selectItem(id, focus) {
  if (!session.filtered.some((item) => item.id === id)) return;
  session.selectedId = id;
  renderDynamic({ focusSelected: focus });
}

function exportCurrentItems() {
  if (!session.filtered.length) {
    showToast("当前筛选结果为 0 条，无法导出");
    return;
  }
  downloadCsv(createFilename(), buildDiffCsv(session.filtered));
  showToast(`已导出 ${session.filtered.length} 条差异记录`);
}

function createFilename() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  const date = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`;
  const time = `${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `账清AI_差异清单_${date}_${time}.csv`;
}

async function copySummary() {
  if (!session.result) return;
  const summary = buildSummary(session.result);
  const text = [summary.headline, ...summary.bullets].join("\n");
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
    else if (!legacyCopy(text)) throw new Error("copy failed");
    showToast("摘要已复制，可直接粘贴到对账邮件中");
  } catch {
    showToast("浏览器未允许复制，请手动选择摘要文字");
  }
}

function legacyCopy(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  const copied = document.execCommand("copy");
  textarea.remove();
  return copied;
}

function toggleSummary(button) {
  const body = session.root.querySelector("#summary-body");
  if (!body) return;
  body.hidden = !body.hidden;
  button.setAttribute("aria-expanded", String(!body.hidden));
  button.classList.toggle("is-collapsed", body.hidden);
  button.title = body.hidden ? "展开摘要" : "折叠摘要";
  button.querySelector(".sr-only").textContent = body.hidden ? "展开摘要" : "折叠摘要";
}

function updateExportButton() {
  const button = session.root.querySelector("[data-export-button]");
  if (!button) return;
  const count = session.filtered.length;
  button.disabled = count === 0;
  button.title = count === 0 ? "当前筛选结果为 0 条，无法导出" : `导出当前筛选后的 ${count} 条异常`;
  const label = button.querySelector("[data-export-label]");
  if (label) label.textContent = `导出差异 CSV（${count} 条）`;
}

function animateNumbers() {
  const elements = [...session.root.querySelectorAll("[data-animate-number]")];
  if (!elements.length || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const start = performance.now();
  const duration = 240;
  const tick = (now) => {
    const progress = Math.min(1, (now - start) / duration);
    const eased = 1 - (1 - progress) ** 3;
    for (const element of elements) {
      const target = Number(element.dataset.value);
      const value = target * eased;
      if (element.dataset.format === "money") element.textContent = formatMoney(value);
      else if (element.dataset.format === "percent") element.textContent = formatPercent(value);
      else element.textContent = formatNumber(Math.round(value), 0);
    }
    if (progress < 1) session.animationFrame = requestAnimationFrame(tick);
  };
  session.animationFrame = requestAnimationFrame(tick);
}

function createFilters() {
  return { types: new Set(), supplier: "", query: "", sort: "amount" };
}

function normalizeSource(source) {
  return {
    label: source?.label === "本地文件" ? "本地文件" : "模拟数据",
    files: Array.isArray(source?.files) ? source.files.map(String) : [],
  };
}

function captureFocus() {
  const active = document.activeElement;
  if (!session.root.contains(active) || !active.dataset.focusKey) return null;
  return { key: active.dataset.focusKey, start: active.selectionStart, end: active.selectionEnd };
}

function restoreFocus(focus) {
  if (!focus) return;
  const element = focusByKey(focus.key);
  if (element?.setSelectionRange && focus.start != null) {
    try { element.setSelectionRange(focus.start, focus.end); } catch { /* 非文本控件无需恢复光标 */ }
  }
}

function focusByKey(key) {
  const element = [...session.root.querySelectorAll("[data-focus-key]")].find((node) => node.dataset.focusKey === key);
  element?.focus({ preventScroll: true });
  return element;
}

function focusSelectedRow() {
  const selected = session.root.querySelector(".exception-row.is-selected");
  selected?.focus({ preventScroll: true });
  selected?.scrollIntoView({ block: "nearest" });
}

function showToast(message) {
  const toast = session.root.querySelector("[data-toast]");
  if (!toast) return;
  window.clearTimeout(session.toastTimer);
  toast.textContent = message;
  toast.classList.add("is-visible");
  session.toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 2600);
}
