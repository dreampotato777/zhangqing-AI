import { getExceptionReason } from "../report/summary.js";
import { icon } from "./constants.js";
import { escapeHtml, formatDelta, formatMoney, formatNumber, typeBadge } from "./format.js";
import { renderState } from "./stateView.js";

export function renderDetail(item) {
  if (!item) return `<aside class="detail-panel detail-empty">${renderState("detail")}</aside>`;

  return `<aside class="detail-panel" aria-label="异常原始明细对比">
    <div class="detail-heading">
      <div class="detail-title-line">${typeBadge(item.type)}<h2 title="${escapeHtml(item.materialName)}">${escapeHtml(item.materialName)}</h2><strong>${formatMoney(item.amountImpact)}</strong></div>
      <div class="match-key" title="单据编号 + 供应商编码 + 物料编码">
        <span><small>单据</small>${escapeHtml(item.key.docNo)}</span><i>+</i>
        <span><small>供应商</small>${escapeHtml(item.key.supplierCode)}</span><i>+</i>
        <span><small>物料</small>${escapeHtml(item.key.materialCode)}</span>
      </div>
    </div>
    <div class="comparison-grid">
      ${renderSide("采购台账（我方）", "left", item)}
      <div class="comparison-bridge" aria-hidden="true"><span>对比</span></div>
      ${renderSide("供应商送货记录", "right", item)}
    </div>
    <div class="difference-reason"><span>${icon("info")}</span><div><strong>差异说明</strong><p>${escapeHtml(getExceptionReason(item))}</p></div></div>
  </aside>`;
}

function renderSide(title, side, item) {
  const records = item[side];
  return `<section class="record-side record-side-${side}">
    <div class="record-side-heading"><h3>${title}</h3><span>${records.length} 条原记录</span></div>
    <div class="record-stack">
      ${records.length ? records.map((record, index) => renderRecord(record, item, side, index)).join("") : '<div class="record-placeholder"><span>＋</span><strong>该侧无对应记录</strong><p>请根据差异说明补齐单据</p></div>'}
    </div>
  </section>`;
}

function renderRecord(record, item, side, index) {
  const duplicate = item.type === "duplicate" && index > 0;
  const diffRecord = side === "left" ? item.diffLeft : item.diffRight;
  const involved =
    item.diffFields.length > 0 &&
    (diffRecord ? diffRecord.rowIndex === record.rowIndex : index === 0);
  return `<article class="record-card ${duplicate ? "is-duplicate" : ""}">
    <div class="record-card-heading"><strong>原记录 ${index + 1}</strong>${duplicate ? '<span class="duplicate-badge">重复</span>' : ""}</div>
    <dl class="record-fields">
      ${textField("单据编号", record.docNo)}
      ${textField("供应商编码", record.supplierCode)}
      ${textField("物料编码", record.materialCode)}
      ${textField("物料名称", record.materialName)}
      ${valueField("数量", "qty", record.qty, item, side, involved)}
      ${valueField("未税单价", "unitPrice", record.unitPrice, item, side, involved)}
      ${textField("业务日期", record.date)}
    </dl>
    <div class="record-source" title="${escapeHtml(record.fileName)} · 第 ${record.rowIndex} 行">${icon("file")}<span>${escapeHtml(record.fileName)}</span><i>·</i><strong>第 ${record.rowIndex} 行</strong></div>
  </article>`;
}

function textField(label, value) {
  return `<div class="record-field"><dt>${label}</dt><dd title="${escapeHtml(value)}">${escapeHtml(value)}</dd></div>`;
}

function valueField(label, field, value, item, side, involved) {
  const highlighted = item.diffFields.includes(field);
  const display = field === "unitPrice" ? formatMoney(value) : formatNumber(value);
  if (!highlighted || !involved) {
    return `<div class="record-field ${highlighted && involved ? "is-different" : ""}"><dt>${label}${field === "unitPrice" ? "（元）" : ""}</dt><dd title="${escapeHtml(display)}">${escapeHtml(display)}</dd></div>`;
  }
  // 差额取自实际产生差异的那一对记录（diffLeft / diffRight），
  // 多行同键时不再用两侧首条相减，避免出现与差异说明矛盾的 0 差额。
  const own = side === "left" ? item.diffLeft : item.diffRight;
  const other = side === "left" ? item.diffRight : item.diffLeft;
  const left = own && other ? (side === "left" ? own : other) : item.left[0];
  const right = own && other ? (side === "right" ? own : other) : item.right[0];
  const difference = left && right ? right[field] - left[field] : 0;
  const badge = side === "right" ? `<span class="delta-badge">${formatDelta(field, difference)}</span>` : "";
  return `<div class="record-field is-different"><dt>${label}${field === "unitPrice" ? "（元）" : ""}</dt><dd title="${escapeHtml(display)}">${escapeHtml(display)}${badge}</dd></div>`;
}
