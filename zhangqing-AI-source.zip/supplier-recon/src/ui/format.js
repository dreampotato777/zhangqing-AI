import { TYPE_META } from "./constants.js";

export function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character]);
}

export function formatNumber(value, maximumFractionDigits = 2) {
  return Number(value || 0).toLocaleString("zh-CN", { maximumFractionDigits });
}

export function formatMoney(value) {
  return `¥${Number(value || 0).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatPercent(value) {
  const rounded = Math.round(value * 10) / 10;
  return `${Number.isInteger(rounded) ? rounded : rounded.toFixed(1)}%`;
}

export function typeBadge(type) {
  const meta = TYPE_META[type] || { label: type, color: "var(--report-muted)", background: "var(--report-panel)" };
  return `<span class="type-badge" style="--type-color:${meta.color};--type-bg:${meta.background}"><i></i>${escapeHtml(meta.label)}</span>`;
}

export function formatDelta(field, difference) {
  const sign = difference > 0 ? "+" : difference < 0 ? "−" : "";
  const absolute = Math.abs(difference);
  return `${sign}${field === "unitPrice" ? formatMoney(absolute) : formatNumber(absolute)}`;
}
