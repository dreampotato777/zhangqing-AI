export const TYPE_ORDER = ["qty_diff", "price_diff", "duplicate", "missing_left", "missing_right"];

export const TYPE_META = {
  qty_diff: { label: "数量不符", color: "var(--report-qty-text)", background: "var(--report-qty-bg)" },
  price_diff: { label: "单价差异", color: "var(--report-price-text)", background: "var(--report-price-bg)" },
  duplicate: { label: "重复记录", color: "var(--report-duplicate-text)", background: "var(--report-duplicate-bg)" },
  missing_left: { label: "台账缺单", color: "var(--report-missing-left-text)", background: "var(--report-missing-left-bg)" },
  missing_right: { label: "送货缺单", color: "var(--report-missing-right-text)", background: "var(--report-missing-right-bg)" },
};

const ICON_PATHS = {
  download: '<path d="M12 3v12m-4-4 4 4 4-4M5 16v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3"/>',
  copy: '<rect x="8" y="8" width="11" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h2"/>',
  chevron: '<path d="m8 10 4 4 4-4"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  close: '<path d="m7 7 10 10M17 7 7 17"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  alert: '<path d="M12 4 3 20h18L12 4Z"/><path d="M12 9v5m0 3h.01"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5M9 13h6m-6 4h4"/>',
  empty: '<path d="M4 13 6.5 5h11l2.5 8v6H4v-6Z"/><path d="M4 13h4l1.5 2h5L16 13h4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  filter: '<path d="M4 6h16M7 12h10m-7 6h4"/>',
  keyboard: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M11 10h.01M15 10h.01M17 14H7"/>',
};

export function icon(name, className = "") {
  return `<svg class="report-icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[name] || ICON_PATHS.info}</svg>`;
}
