import { icon } from "./constants.js";
import { escapeHtml } from "./format.js";

export function renderState(kind, message = "") {
  const states = {
    success: { icon: "check", title: "本次核对未发现异常 ✓", text: "所有匹配键的数量与单价均一致，可以安心归档本次结果。" },
    error: { icon: "alert", title: "暂时无法展示对账结果", text: message || "请检查数据结构后重试，或联系提供数据的同学确认字段。" },
    empty: { icon: "search", title: "没有符合条件的异常", text: "试试减少异常类型、更换供应商，或修改搜索关键词。" },
    detail: { icon: "empty", title: "暂无可展示的明细", text: "调整筛选并选择一条异常后，可在这里核对两侧原始记录。" },
  };
  const current = states[kind] || states.error;
  return `<div class="state-view state-${kind}" role="${kind === "error" ? "alert" : "status"}">
    <span class="state-icon">${icon(current.icon)}</span>
    <h2>${escapeHtml(current.title)}</h2>
    <p>${escapeHtml(current.text)}</p>
    ${kind === "empty" ? `<button type="button" class="button button-secondary" data-action="clear-filters">${icon("close")}清除筛选</button>` : ""}
  </div>`;
}
