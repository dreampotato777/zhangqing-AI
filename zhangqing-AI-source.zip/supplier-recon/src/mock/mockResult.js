// 本文件全部为企业、物料与交易均为虚构的演示数据，不对应任何真实业务。
const SUPPLIERS = [
  { code: "SUP-A01", name: "澄川样例五金" },
  { code: "SUP-B02", name: "岚桥样例材料" },
  { code: "SUP-C03", name: "锦川样例传动" },
  { code: "SUP-D04", name: "新禾样例包装" },
  { code: "SUP-E05", name: "云浦样例橡塑" },
  { code: "SUP-F06", name: "北陆样例金属" },
];

const MATERIALS = [
  { code: "M-BOLT-M8", name: "六角螺栓 M8×30" },
  { code: "M-SUS-304", name: "304 不锈钢板" },
  { code: "M-BEAR-6204", name: "深沟球轴承 6204" },
  { code: "M-SEAL-NBR", name: "丁腈橡胶密封圈" },
  { code: "M-BOX-600", name: "五层瓦楞包装箱" },
  { code: "M-AL-5052", name: "5052 铝合金板" },
  { code: "M-NUT-M10", name: "法兰螺母 M10" },
  { code: "M-CABLE-2.5", name: "铜芯控制电缆 2.5mm²" },
];

function makeRecord(side, docNo, supplierIndex, materialIndex, spec) {
  const [rowIndex, qty, unitPrice, date] = spec;
  return {
    fileName: side === "left" ? "purchase_ledger.csv" : "supplier_delivery.csv",
    rowIndex,
    docNo,
    supplierCode: SUPPLIERS[supplierIndex].code,
    materialCode: MATERIALS[materialIndex].code,
    materialName: MATERIALS[materialIndex].name,
    qty,
    unitPrice,
    date,
  };
}

function makeItem(id, type, supplierIndex, materialIndex, docNo, amountImpact, left, right, diffFields = [], reason = "") {
  const supplier = SUPPLIERS[supplierIndex];
  const material = MATERIALS[materialIndex];
  return {
    id,
    key: { docNo, supplierCode: supplier.code, materialCode: material.code },
    supplierName: supplier.name,
    materialName: material.name,
    type,
    amountImpact,
    diffFields,
    left: left.map((spec) => makeRecord("left", docNo, supplierIndex, materialIndex, spec)),
    right: right.map((spec) => makeRecord("right", docNo, supplierIndex, materialIndex, spec)),
    reason,
  };
}

const items = [
  makeItem("EX-001", "qty_diff", 0, 0, "PO-202610-001", 48, [[12, 100, 2.4, "2026-10-03"]], [[21, 80, 2.4, "2026-10-04"]], ["qty"], "送货数量比采购台账少 20 件，建议核对未交货数量。"),
  makeItem("EX-002", "price_diff", 0, 2, "PO-202610-002", 275, [[18, 50, 86, "2026-10-03"]], [[26, 50, 91.5, "2026-10-05"]], ["unitPrice"]),
  makeItem("EX-003", "qty_diff", 0, 3, "PO-202610-003", 24, [[25, 500, 1.2, "2026-10-04"]], [[33, 520, 1.2, "2026-10-06"]], ["qty"]),
  makeItem("EX-004", "duplicate", 0, 1, "PO-202610-004", 15360, [[31, 12, 1280, "2026-10-05"]], [[39, 12, 1280, "2026-10-06"], [40, 12, 1280, "2026-10-06"]], [], "供应商送货记录出现两条相同数量与单价的记录，请确认是否重复计账。"),
  makeItem("EX-005", "missing_left", 0, 4, "PO-202610-005", 720, [], [[47, 200, 3.6, "2026-10-07"]]),
  makeItem("EX-006", "price_diff", 0, 5, "PO-202610-006", 540, [[42, 30, 420, "2026-10-07"]], [[52, 30, 438, "2026-10-08"]], ["unitPrice"]),
  makeItem("EX-007", "missing_right", 0, 6, "PO-202610-007", 850, [[49, 1000, 0.85, "2026-10-08"]], []),
  makeItem("EX-008", "qty_diff", 0, 2, "PO-202610-008", 430, [[55, 80, 86, "2026-10-09"]], [[61, 75, 86, "2026-10-10"]], ["qty"]),
  makeItem("EX-009", "duplicate", 0, 0, "PO-202610-009", 480, [[63, 200, 2.4, "2026-10-10"]], [[69, 200, 2.4, "2026-10-11"], [70, 200, 2.4, "2026-10-11"]]),

  makeItem("EX-010", "qty_diff", 1, 1, "PO-202610-010", 2560, [[71, 20, 1280, "2026-10-11"]], [[78, 18, 1280, "2026-10-12"]], ["qty"]),
  makeItem("EX-011", "price_diff", 1, 3, "PO-202610-011", 150, [[76, 1000, 1.2, "2026-10-12"]], [[82, 1000, 1.35, "2026-10-13"]], ["unitPrice"]),
  makeItem("EX-012", "missing_right", 1, 4, "PO-202610-012", 1080, [[81, 300, 3.6, "2026-10-13"]], []),
  makeItem("EX-013", "duplicate", 1, 6, "PO-202610-013", 510, [[86, 600, 0.85, "2026-10-14"]], [[92, 600, 0.85, "2026-10-15"], [93, 600, 0.85, "2026-10-15"]]),

  makeItem("EX-014", "qty_diff", 2, 2, "PO-202610-014", 172, [[94, 60, 86, "2026-10-15"]], [[101, 62, 86, "2026-10-16"]], ["qty"]),
  makeItem("EX-015", "price_diff", 2, 5, "PO-202610-015", 420, [[99, 12, 420, "2026-10-16"]], [[107, 12, 455, "2026-10-17"]], ["unitPrice"]),
  makeItem("EX-016", "missing_left", 2, 0, "PO-202610-016", 1920, [], [[112, 800, 2.4, "2026-10-18"]]),
  makeItem("EX-017", "qty_diff", 2, 3, "PO-202610-017", 60, [[108, 1000, 1.2, "2026-10-18"]], [[116, 950, 1.2, "2026-10-19"]], ["qty"]),

  makeItem("EX-018", "price_diff", 3, 4, "PO-202610-018", 300, [[117, 600, 3.6, "2026-10-19"]], [[124, 600, 4.1, "2026-10-20"]], ["unitPrice"]),
  makeItem("EX-019", "duplicate", 3, 1, "PO-202610-019", 25600, [[121, 20, 1280, "2026-10-20"]], [[129, 20, 1280, "2026-10-21"], [130, 20, 1280, "2026-10-21"]]),
  makeItem("EX-020", "missing_right", 3, 7, "PO-202610-020", 1850, [[126, 100, 18.5, "2026-10-21"]], []),

  makeItem("EX-021", "qty_diff", 4, 6, "PO-202610-021", 170, [[132, 2000, 0.85, "2026-10-22"]], [[139, 1800, 0.85, "2026-10-23"]], ["qty"]),
  makeItem("EX-022", "price_diff", 4, 0, "PO-202610-022", 750, [[137, 3000, 2.4, "2026-10-23"]], [[144, 3000, 2.65, "2026-10-24"]], ["unitPrice"]),

  makeItem("EX-023", "missing_left", 5, 2, "PO-202610-023", 860, [], [[151, 10, 86, "2026-10-25"]]),
  makeItem("EX-024", "qty_diff", 5, 5, "PO-202610-024", 4200, [[148, 20, 420, "2026-10-26"]], [[156, 10, 420, "2026-10-27"]], ["qty"]),
];

export const mockResult = {
  totals: {
    leftCount: 123,
    rightCount: 127,
    matchedKeys: 96,
  },
  items,
};

export default mockResult;
