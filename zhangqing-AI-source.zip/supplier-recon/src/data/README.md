# 数据接入（A · CSV 解析）

本目录提供采购台账、送货记录两份模拟数据和一份空白模板。解析逻辑位于 `src/csv.js`，用户上传文件和演示文件共用同一个 `parseCsv`。

## 运行测试

在项目根目录执行：

```bash
node --test tests/csv.test.mjs
```

## 表头与字段

两张表共用表头：

```csv
单据编号,供应商编码,物料编码,数量,未税单价
```

| 列 | 校验规则 | 输出字段 |
| --- | --- | --- |
| 单据编号 | 必填文本，去除首尾空格，保留 `0001` 等前导零 | `documentNo` |
| 供应商编码 | 必填文本，去除首尾空格，保留前导零 | `supplierCode` |
| 物料编码 | 必填文本，去除首尾空格，保留前导零 | `sku` |
| 数量 | 正整数（大于 0） | `quantity`（Number） |
| 未税单价 | 非负人民币金额，最多两位小数 | `unitPriceCents`（整数分） |

单价直接按文本换算成分，避免浮点误差：`12.50` → `1250`，`12.5` → `1250`，`0.07` → `7`。

兼容 UTF-8 BOM、Windows `CRLF` 换行、带引号的逗号以及 `""` 双引号转义。必需列可以换顺序，表头中的额外列会被忽略，但每一行的列数必须与表头一致。

## 返回值

成功：

```js
{
  ok: true,
  rows: [
    {
      documentNo: "D001",
      supplierCode: "S001",
      sku: "M01",
      quantity: 10,
      unitPriceCents: 1250,
      fileName: "purchase-demo.csv",
      recordNumber: 2
    }
  ]
}
```

失败：

```js
{
  ok: false,
  errors: [
    {
      fileName: "purchase-demo.csv",
      recordNumber: 3,
      message: "数量「0」必须大于 0"
    }
  ]
}
```

- `recordNumber` 从 1 开始，表头是第 1 条，第一条数据是第 2 条。
- 文件级错误（空文件、编码错误、引号未闭合）的 `recordNumber` 为 `null`；表头缺列的 `recordNumber` 为 `1`。
- 只要存在任何错误，整份文件返回失败，不返回残缺的 `rows`。
- 解析过程不去重，重复记录会原样保留，由 B 负责判断。
- 空白模板 `template.csv` 只有表头，直接导入会返回“没有数据行”，这是预期行为。

## 模拟数据预期

| 文件 | 预期记录数 |
| --- | --- |
| `purchase-demo.csv` | 7 |
| `delivery-demo.csv` | 8 |

供应商统一为 `S001`，逐单据预期：

| 单据 | 采购侧 | 送货侧 | B 的预期结果 |
| --- | --- | --- | --- |
| D001 | M01 / 10 / 12.50 | M01 / 10 / 12.50 | 匹配 |
| D002 | M02 / 10 / 18.00 | M02 / 12 / 18.00 | 数量差异 |
| D003 | M03 / 5 / 20.00 | M03 / 5 / 22.00 | 单价差异 |
| D004 | M04 / 4 / 30.00 | 无 | 送货缺失 1 条 |
| D005 | 无 | M05 / 3 / 40.00 | 采购缺失 1 条 |
| D006 | M06 / 6 / 10.00，1 条 | M06 / 6 / 10.00，2 条 | 送货重复，两条都要保留 |
| D007 | M07 / 8 / 25.00 | M07 / 9 / 26.00 | 数量 + 单价差异 |
| D008 | M08 / 2 / 15.00 | M09 / 2 / 15.00 | 物料编码不同，两个方向各缺失 1 条 |

D006 的两条送货记录分别是第 6、7 条记录，内容完全相同，`recordNumber` 分别为 `6`、`7`。

D008 因为匹配键包含物料编码，采购侧的 `M08` 在送货侧找不到，送货侧的 `M09` 在采购侧找不到，所以 B 应得到采购缺失 1 条、送货缺失 1 条。

## D 的调用示例

以下代码可直接放进 `src/main.js`。

### 载入模拟数据

Vite 支持 `?raw`，演示文件与用户上传文件走同一套解析逻辑：

```js
import { parseCsv, readCsvFile } from "./csv.js";
import purchaseDemoCsv from "./data/purchase-demo.csv?raw";
import deliveryDemoCsv from "./data/delivery-demo.csv?raw";

const purchase = parseCsv(purchaseDemoCsv, "purchase-demo.csv");
const delivery = parseCsv(deliveryDemoCsv, "delivery-demo.csv");

if (!purchase.ok || !delivery.ok) {
  // 演示数据理论上不会失败；仍建议把 errors 渲染出来便于排查
  console.error(purchase.errors ?? delivery.errors);
} else {
  // purchase.rows.length === 7，delivery.rows.length === 8
  // 交给 B 的对账函数
}
```

### 用户上传 CSV

```js
const fileInput = document.querySelector("#purchaseFile");
fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  const result = await readCsvFile(file);
  if (!result.ok) {
    // result.errors 形如 [{ fileName, recordNumber, message }]
    // 可直接逐条渲染到错误列表
    return;
  }

  // result.rows 为标准化记录，交给 B
});
```

### B 的使用方式

B 只需要接收 `rows`：

```js
const purchaseRows = purchase.ok ? purchase.rows : [];
const deliveryRows = delivery.ok ? delivery.rows : [];
// 金额统一用 unitPriceCents 比较，数量用 quantity 比较
// fileName + recordNumber 可定位来源；重复记录未被去重
```

空白模板可直接提供给用户下载：`src/data/template.csv`。

## 对账规则（B）

入口是 `src/reconcile.js`：

```js
import { reconcile } from "../reconcile.js";

const result = reconcile(purchase.rows, delivery.rows);
```

### 匹配口径

- 匹配键为 **单据编号 + 供应商编码 + 物料编码**，三项完全相同才算同一键；物料编码不同即为两条独立记录。
- 同一键内先提取重复记录：与同侧首条「数量 + 单价」完全相同的后续记录记为「重复计账」，两侧都重复时分别上报。
- 剩余记录先按「数量 + 单价一致」配对（与行序无关，换行序不产生误报）；配不上的按数量、单价、行号排序后逐对比较。
- 数量、未税单价严格相等；可选参数 `quantityTolerance`、`priceToleranceCents` 放宽，默认 `0`。
- 配对后仍多出的记录记为「缺单漏单」，缺失侧为没有该记录的一侧。
- 不去重，两侧原始记录全部保留，`fileName` 与 `recordNumber` 原样带出。

### 返回值

```js
{
  lines: [
    {
      key: "D001|S001|M01",
      documentNo: "D001",
      supplierCode: "S001",
      sku: "M01",
      status: "matched", // matched | diff | duplicate | missing
      purchaseRows: [],
      deliveryRows: [],
      exceptions: []
    }
  ],
  exceptions: [
    {
      id: "qty:D002|S001|M02:3",
      type: "数量不符", // 数量不符 | 单价差异 | 重复计账 | 缺单漏单
      key: "D002|S001|M02",
      documentNo: "D002",
      supplierCode: "S001",
      sku: "M02",
      purchase: {},
      delivery: {},
      purchaseRows: [],
      deliveryRows: [],
      quantityDiff: 2, // 送货 − 采购
      priceDiffCents: 0,
      message: "数量不符：采购 10，送货 12（差 +2）"
    }
  ],
  summary: {
    purchaseRowCount: 7,
    deliveryRowCount: 8,
    keyCount: 9,
    matchedKeyCount: 1,
    exceptionKeyCount: 8,
    exceptionCount: 9,
    missingPurchaseCount: 2,
    missingDeliveryCount: 2,
    duplicateCount: 1,
    byType: { "数量不符": 2, "单价差异": 2, "重复计账": 1, "缺单漏单": 4 }
  }
}
```

异常对象按类型附带字段：数量不符用 `quantityDiff`，单价差异用 `priceDiffCents`，重复计账用 `duplicatedSide`、`duplicateCount`、`duplicateRows`，缺单漏单用 `missingSide`、`missingRows`。

### 逐键预期（模拟数据）

| 键 | 采购侧 | 送货侧 | status | 异常 |
| --- | --- | --- | --- | --- |
| D001 / M01 | 10 / 12.50 | 10 / 12.50 | matched | 无 |
| D002 / M02 | 10 / 18.00 | 12 / 18.00 | diff | 数量不符，差 +2 |
| D003 / M03 | 5 / 20.00 | 5 / 22.00 | diff | 单价差异，差 +200 分 |
| D004 / M04 | 4 / 30.00 | 无 | missing | 送货缺失 1 条 |
| D005 / M05 | 无 | 3 / 40.00 | missing | 采购缺失 1 条 |
| D006 / M06 | 1 条 | 2 条 | duplicate | 重复计账，第 7 条为重复 |
| D007 / M07 | 8 / 25.00 | 9 / 26.00 | diff | 数量不符 +1、单价差异 +100 分 |
| D008 / M08 | 2 / 15.00 | 无 | missing | 送货缺失 1 条 |
| D008 / M09 | 无 | 2 / 15.00 | missing | 采购缺失 1 条 |

合计 9 个键、1 个完全匹配、9 条异常：数量不符 2、单价差异 2、重复计账 1、缺单漏单 4（采购缺失 2、送货缺失 2）。

### C 对接方式

- 两侧明细与筛选：用 `lines`，正常与异常行都在。
- 异常列表：用 `exceptions`，`type`、`message` 可直接展示，`purchaseRows` / `deliveryRows` 定位原始记录。
- 统计卡片：用 `summary.byType` 和 `summary.exceptionCount`。
- 差异 CSV：逐条导出 `exceptions` 的 `type`、`documentNo`、`sku`、两侧数量与单价、`message`。

测试：`node --test tests/reconcile.test.mjs`。
