/**
 * 对账规则（B）。
 *
 * 输入是 A 的 parseCsv 输出的 rows：采购台账与供应商送货记录各一份。
 * 按「单据编号 + 供应商编码 + 物料编码」逐键比对，识别数量不符、单价差异、
 * 重复计账、缺单漏单。只做规则判断，不改写、不去重原始记录。
 *
 * 口径：
 * - 匹配键三项完全相同才算同一键，物料编码不同即视为两条独立记录。
 * - 同一键内先提取重复记录：与同侧首条「数量 + 单价」完全相同的后续记录记为重复计账，
 *   两侧都重复时分别上报，避免被一对一配对抵消。
 * - 剩余记录先按「数量 + 单价一致」配对（与行序无关，换行序不产生误报）；
 *   配不上的按数量、单价、行号排序后逐对比较数量与单价，
 *   差异在 quantityTolerance / priceToleranceCents 内视为一致。
 * - 配对后仍多出的记录记为缺单漏单，缺失侧为没有该记录的一侧。
 */

export const EXCEPTION_TYPES = Object.freeze({
  QUANTITY: "数量不符",
  PRICE: "单价差异",
  DUPLICATE: "重复计账",
  MISSING: "缺单漏单",
});

const TYPE_ORDER = [
  EXCEPTION_TYPES.MISSING,
  EXCEPTION_TYPES.DUPLICATE,
  EXCEPTION_TYPES.QUANTITY,
  EXCEPTION_TYPES.PRICE,
];

const SUMMARY_TYPES = [
  EXCEPTION_TYPES.QUANTITY,
  EXCEPTION_TYPES.PRICE,
  EXCEPTION_TYPES.DUPLICATE,
  EXCEPTION_TYPES.MISSING,
];

/**
 * @param {Array<object>} purchaseRows 采购台账记录（parseCsv 的 rows）
 * @param {Array<object>} deliveryRows 送货记录（parseCsv 的 rows）
 * @param {{ quantityTolerance?: number, priceToleranceCents?: number }} [options]
 * @returns {{ lines: Array<object>, exceptions: Array<object>, summary: object }}
 */
export function reconcile(purchaseRows, deliveryRows, options = {}) {
  const purchase = Array.isArray(purchaseRows) ? purchaseRows : [];
  const delivery = Array.isArray(deliveryRows) ? deliveryRows : [];
  const quantityTolerance = normalizeTolerance(options.quantityTolerance);
  const priceToleranceCents = normalizeTolerance(options.priceToleranceCents);

  const groups = new Map();
  for (const row of purchase) {
    const group = ensureGroup(groups, row);
    group.purchase.push(row);
  }
  for (const row of delivery) {
    const group = ensureGroup(groups, row);
    group.delivery.push(row);
  }

  const lines = [];
  const exceptions = [];

  for (const group of groups.values()) {
    const purchaseSide = sortRows(group.purchase);
    const deliverySide = sortRows(group.delivery);
    const lineExceptions = [];

    // 先提取两侧各自的重复记录（与同侧首条完全相同的后续记录），
    // 避免两侧同记录一对一配对后互相抵消、漏报重复计账。
    const purchaseSplit = splitDuplicates(purchaseSide);
    const deliverySplit = splitDuplicates(deliverySide);
    if (purchaseSplit.duplicates.length > 0) {
      lineExceptions.push(
        duplicateException(group, "purchase", purchaseSplit.duplicates, purchaseSide, deliverySide)
      );
    }
    if (deliverySplit.duplicates.length > 0) {
      lineExceptions.push(
        duplicateException(group, "delivery", deliverySplit.duplicates, purchaseSide, deliverySide)
      );
    }

    // 剩余记录配对：先按「数量 + 单价一致」配（与行序无关），配不上的
    // 按数量、单价、行号排序后逐对比较数量与单价。
    const pairing = pairRows(purchaseSplit.pool, deliverySplit.pool);

    for (const [p, d] of pairing.diffPairs) {
      const quantityDiff = d.quantity - p.quantity;
      if (Math.abs(quantityDiff) > quantityTolerance) {
        lineExceptions.push({
          ...baseException(group, EXCEPTION_TYPES.QUANTITY, `qty:${group.key}:${p.recordNumber}`),
          purchaseRows: purchaseSide,
          deliveryRows: deliverySide,
          purchase: p,
          delivery: d,
          quantityDiff,
          message: `数量不符：采购 ${p.quantity}，送货 ${d.quantity}（差 ${signed(quantityDiff)}）`,
        });
      }

      const priceDiffCents = d.unitPriceCents - p.unitPriceCents;
      if (Math.abs(priceDiffCents) > priceToleranceCents) {
        lineExceptions.push({
          ...baseException(group, EXCEPTION_TYPES.PRICE, `price:${group.key}:${p.recordNumber}`),
          purchaseRows: purchaseSide,
          deliveryRows: deliverySide,
          purchase: p,
          delivery: d,
          priceDiffCents,
          message: `单价差异：采购 ${money(p.unitPriceCents)} 元，送货 ${money(d.unitPriceCents)} 元（差 ${signed(priceDiffCents)} 分）`,
        });
      }
    }

    // 配对后仍多出的记录：对侧没有可对应的记录，记为缺单漏单。
    if (pairing.extraPurchase.length > 0) {
      lineExceptions.push(
        missingException(group, "delivery", pairing.extraPurchase, purchaseSide, deliverySide)
      );
    }

    if (pairing.extraDelivery.length > 0) {
      lineExceptions.push(
        missingException(group, "purchase", pairing.extraDelivery, purchaseSide, deliverySide)
      );
    }

    lines.push({
      key: group.key,
      documentNo: group.documentNo,
      supplierCode: group.supplierCode,
      sku: group.sku,
      status: lineStatus(lineExceptions),
      purchaseRows: purchaseSide,
      deliveryRows: deliverySide,
      exceptions: lineExceptions,
    });
    exceptions.push(...lineExceptions);
  }

  lines.sort((a, b) => a.key.localeCompare(b.key));
  exceptions.sort(compareExceptions);

  return { lines, exceptions, summary: buildSummary(lines, exceptions) };
}

export function buildKey(row) {
  return `${row.documentNo}|${row.supplierCode}|${row.sku}`;
}

function ensureGroup(groups, row) {
  const key = buildKey(row);
  if (!groups.has(key)) {
    groups.set(key, {
      key,
      documentNo: row.documentNo,
      supplierCode: row.supplierCode,
      sku: row.sku,
      purchase: [],
      delivery: [],
    });
  }
  return groups.get(key);
}

function baseException(group, type, id) {
  return {
    id,
    type,
    key: group.key,
    documentNo: group.documentNo,
    supplierCode: group.supplierCode,
    sku: group.sku,
  };
}

function duplicateException(group, side, rows, purchaseSide, deliverySide) {
  const sideLabel = side === "purchase" ? "采购" : "送货";
  const numbers = rows.map((row) => row.recordNumber).join("、");
  return {
    ...baseException(group, EXCEPTION_TYPES.DUPLICATE, `dup:${group.key}:${side}`),
    purchaseRows: purchaseSide,
    deliveryRows: deliverySide,
    purchase: purchaseSide[0] ?? null,
    delivery: deliverySide[0] ?? null,
    duplicatedSide: side,
    duplicateCount: rows.length,
    duplicateRows: rows,
    message: `重复计账：${sideLabel}侧有 ${rows.length} 条与同侧首条记录完全相同（记录 ${numbers}）`,
  };
}

function missingException(group, missingSide, rows, purchaseSide, deliverySide) {
  const sideLabel = missingSide === "purchase" ? "采购台账" : "送货记录";
  const otherLabel = missingSide === "purchase" ? "送货记录" : "采购台账";
  const numbers = rows.map((row) => row.recordNumber).join("、");
  return {
    ...baseException(group, EXCEPTION_TYPES.MISSING, `missing:${group.key}:${missingSide}`),
    purchaseRows: purchaseSide,
    deliveryRows: deliverySide,
    purchase: purchaseSide[0] ?? null,
    delivery: deliverySide[0] ?? null,
    missingSide,
    missingRows: rows,
    message: `缺单漏单：${sideLabel}中无对应记录，仅见${otherLabel}（记录 ${numbers}）`,
  };
}

function lineStatus(exceptions) {
  if (exceptions.some((item) => item.type === EXCEPTION_TYPES.MISSING)) return "missing";
  if (exceptions.some((item) => item.type === EXCEPTION_TYPES.DUPLICATE)) return "duplicate";
  if (exceptions.length > 0) return "diff";
  return "matched";
}

function compareExceptions(a, b) {
  const byType = TYPE_ORDER.indexOf(a.type) - TYPE_ORDER.indexOf(b.type);
  if (byType !== 0) return byType;
  return a.key.localeCompare(b.key) || a.id.localeCompare(b.id);
}

function buildSummary(lines, exceptions) {
  const byType = {};
  for (const type of SUMMARY_TYPES) byType[type] = 0;
  for (const exception of exceptions) byType[exception.type] += 1;

  return {
    purchaseRowCount: sumRows(lines, "purchaseRows"),
    deliveryRowCount: sumRows(lines, "deliveryRows"),
    keyCount: lines.length,
    matchedKeyCount: lines.filter((line) => line.status === "matched").length,
    exceptionKeyCount: lines.filter((line) => line.status !== "matched").length,
    exceptionCount: exceptions.length,
    missingPurchaseCount: exceptions.filter((item) => item.missingSide === "purchase").length,
    missingDeliveryCount: exceptions.filter((item) => item.missingSide === "delivery").length,
    duplicateCount: exceptions
      .filter((item) => item.type === EXCEPTION_TYPES.DUPLICATE)
      .reduce((total, item) => total + item.duplicateCount, 0),
    byType,
  };
}

function sumRows(lines, field) {
  return lines.reduce((total, line) => total + line[field].length, 0);
}

function sortRows(rows) {
  return [...rows].sort(
    (a, b) => (a.recordNumber ?? 0) - (b.recordNumber ?? 0) || String(a.fileName).localeCompare(String(b.fileName))
  );
}

function sameAmount(a, b) {
  return a.quantity === b.quantity && a.unitPriceCents === b.unitPriceCents;
}

/**
 * 按行序提取同一键内某侧的重复记录：与该侧首条「数量 + 单价」完全相同的
 * 后续记录为重复，其余（每个数量 + 单价组合的首条）进入配对池。
 */
function splitDuplicates(rows) {
  const seen = new Set();
  const pool = [];
  const duplicates = [];
  for (const row of rows) {
    const fingerprint = `${row.quantity}|${row.unitPriceCents}`;
    if (seen.has(fingerprint)) {
      duplicates.push(row);
    } else {
      seen.add(fingerprint);
      pool.push(row);
    }
  }
  return { pool, duplicates };
}

/**
 * 同键内剩余记录的配对：
 * 1. 先按「数量 + 单价严格一致」配对，与行序无关（换行序不产生误报）；
 * 2. 配不上的按数量、单价、行号排序后逐对配为差异对；
 * 3. 仍多出的记录按侧返回，由调用方记为缺单漏单。
 */
function pairRows(purchasePool, deliveryPool) {
  const usedDelivery = new Array(deliveryPool.length).fill(false);
  const restPurchase = [];
  const restDelivery = [];

  for (const p of purchasePool) {
    let matched = false;
    for (let j = 0; j < deliveryPool.length; j += 1) {
      if (!usedDelivery[j] && sameAmount(p, deliveryPool[j])) {
        usedDelivery[j] = true;
        matched = true;
        break;
      }
    }
    if (!matched) restPurchase.push(p);
  }
  for (let j = 0; j < deliveryPool.length; j += 1) {
    if (!usedDelivery[j]) restDelivery.push(deliveryPool[j]);
  }

  const byAmount = (a, b) =>
    a.quantity - b.quantity ||
    a.unitPriceCents - b.unitPriceCents ||
    (a.recordNumber ?? 0) - (b.recordNumber ?? 0);
  restPurchase.sort(byAmount);
  restDelivery.sort(byAmount);

  const diffPairCount = Math.min(restPurchase.length, restDelivery.length);
  const diffPairs = [];
  for (let i = 0; i < diffPairCount; i += 1) {
    diffPairs.push([restPurchase[i], restDelivery[i]]);
  }

  return {
    diffPairs,
    extraPurchase: restPurchase.slice(diffPairCount),
    extraDelivery: restDelivery.slice(diffPairCount),
  };
}

function normalizeTolerance(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : 0;
}

function signed(value) {
  return value > 0 ? `+${value}` : String(value);
}

function money(cents) {
  return (cents / 100).toFixed(2);
}
