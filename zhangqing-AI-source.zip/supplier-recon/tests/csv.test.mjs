import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { File } from "node:buffer";

import { parseCsv, readCsvFile } from "../src/csv.js";

const testDir = path.dirname(fileURLToPath(import.meta.url));
const dataPath = (fileName) => path.join(testDir, "..", "src", "data", fileName);
const readData = (fileName) => readFileSync(dataPath(fileName), "utf8");

const HEADER = "单据编号,供应商编码,物料编码,数量,未税单价";

test("采购样例：读取 7 条记录并正确换算金额", () => {
  const result = parseCsv(readData("purchase-demo.csv"), "purchase-demo.csv");

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 7);
  assert.deepEqual(result.rows[0], {
    documentNo: "D001",
    supplierCode: "S001",
    sku: "M01",
    quantity: 10,
    unitPriceCents: 1250,
    fileName: "purchase-demo.csv",
    recordNumber: 2,
  });
  assert.deepEqual(
    result.rows.map((row) => row.documentNo),
    ["D001", "D002", "D003", "D004", "D006", "D007", "D008"]
  );
  assert.equal(result.rows.find((row) => row.documentNo === "D004").sku, "M04");
  assert.equal(result.rows.find((row) => row.documentNo === "D008").sku, "M08");
});

test("送货样例：读取 8 条记录，D006 的两条重复记录都保留", () => {
  const result = parseCsv(readData("delivery-demo.csv"), "delivery-demo.csv");

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 8);

  const d006 = result.rows.filter((row) => row.documentNo === "D006");
  assert.equal(d006.length, 2);
  assert.deepEqual(
    d006.map((row) => row.recordNumber),
    [6, 7]
  );
  assert.deepEqual(
    d006.map((row) => [row.sku, row.quantity, row.unitPriceCents]),
    [
      ["M06", 6, 1000],
      ["M06", 6, 1000],
    ]
  );

  const d008 = result.rows.filter((row) => row.documentNo === "D008");
  assert.equal(d008.length, 1);
  assert.equal(d008[0].sku, "M09");
});

test("兼容 UTF-8 BOM、CRLF 换行和前导零", () => {
  const text =
    "\uFEFF" + HEADER + "\r\n0001,0001,M01,2,12.5\r\n";

  const result = parseCsv(text, "bom.csv");

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 1);
  assert.equal(result.rows[0].documentNo, "0001");
  assert.equal(result.rows[0].supplierCode, "0001");
  assert.equal(result.rows[0].unitPriceCents, 1250);
  assert.equal(result.rows[0].recordNumber, 2);
});

test("支持引号包裹的逗号和双引号转义", () => {
  const text = [
    HEADER,
    '"D,001","S""01",M01,2,"12.50"',
    '"D002",S002,"M,02",3,8',
  ].join("\r\n");

  const result = parseCsv(text, "quoted.csv");

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 2);
  assert.equal(result.rows[0].documentNo, "D,001");
  assert.equal(result.rows[0].supplierCode, 'S"01');
  assert.equal(result.rows[0].unitPriceCents, 1250);
  assert.equal(result.rows[1].sku, "M,02");
  assert.equal(result.rows[1].unitPriceCents, 800);
});

test("表头缺列时整体失败，并指出缺失字段", () => {
  const text = "单据编号,供应商编码,数量,未税单价\nD001,S001,2,12.50";

  const result = parseCsv(text, "missing-column.csv");

  assert.equal(result.ok, false);
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].fileName, "missing-column.csv");
  assert.equal(result.errors[0].recordNumber, 1);
  assert.match(result.errors[0].message, /物料编码/);
});

test("空文件和只有表头的空表都返回文件级错误", () => {
  const empty = parseCsv("", "empty.csv");
  assert.equal(empty.ok, false);
  assert.equal(empty.errors[0].recordNumber, null);
  assert.match(empty.errors[0].message, /为空/);

  const headerOnly = parseCsv(HEADER + "\r\n", "header-only.csv");
  assert.equal(headerOnly.ok, false);
  assert.equal(headerOnly.errors[0].recordNumber, null);
  assert.match(headerOnly.errors[0].message, /没有数据行/);
});

test("非法数量逐条报错，记录序号从表头之后开始", () => {
  const text = [
    HEADER,
    "D001,S001,M01,0,12.50",
    "D002,S001,M02,-1,12.50",
    "D003,S001,M03,1.5,12.50",
    "D004,S001,M04,abc,12.50",
  ].join("\n");

  const result = parseCsv(text, "bad-quantity.csv");

  assert.equal(result.ok, false);
  assert.equal(result.errors.length, 4);
  assert.deepEqual(
    result.errors.map((error) => error.recordNumber),
    [2, 3, 4, 5]
  );
  for (const error of result.errors) {
    assert.equal(error.fileName, "bad-quantity.csv");
    assert.match(error.message, /数量/);
  }
});

test("非法单价（负数、超过两位小数、非数字）逐条报错", () => {
  const text = [
    HEADER,
    "D001,S001,M01,1,-1.00",
    "D002,S001,M02,1,12.345",
    "D003,S001,M03,1,abc",
  ].join("\n");

  const result = parseCsv(text, "bad-price.csv");

  assert.equal(result.ok, false);
  assert.equal(result.errors.length, 3);
  assert.deepEqual(
    result.errors.map((error) => error.recordNumber),
    [2, 3, 4]
  );
  for (const error of result.errors) {
    assert.match(error.message, /未税单价/);
  }
});

test("必填字段缺失时给出明确提示", () => {
  const text = [HEADER, "D001,,M01,1,12.50"].join("\n");

  const result = parseCsv(text, "missing-field.csv");

  assert.equal(result.ok, false);
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].recordNumber, 2);
  assert.match(result.errors[0].message, /供应商编码不能为空/);
});

test("数据行列数与表头不一致时整体失败", () => {
  const text = [HEADER, "D001,S001,M01,1"].join("\n");

  const result = parseCsv(text, "bad-columns.csv");

  assert.equal(result.ok, false);
  assert.equal(result.errors.length, 1);
  assert.equal(result.errors[0].recordNumber, 2);
  assert.match(result.errors[0].message, /列数不符/);
});

test("单价按文本换算为整数分", () => {
  const text = [
    HEADER,
    "D001,S001,M01,1,0",
    "D002,S001,M02,1,0.07",
    "D003,S001,M03,1,12",
    "D004,S001,M04,1,12.5",
  ].join("\n");

  const result = parseCsv(text, "price.csv");

  assert.equal(result.ok, true);
  assert.deepEqual(
    result.rows.map((row) => row.unitPriceCents),
    [0, 7, 1200, 1250]
  );
});

test("重复记录原样保留，不做去重", () => {
  const text = [
    HEADER,
    "D001,S001,M01,10,12.50",
    "D001,S001,M01,10,12.50",
  ].join("\n");

  const result = parseCsv(text, "duplicate.csv");

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 2);
  assert.deepEqual(
    result.rows.map((row) => row.recordNumber),
    [2, 3]
  );
});

test("readCsvFile 严格按 UTF-8 解码并复用 parseCsv", async () => {
  const file = new File(
    ["\uFEFF" + HEADER + "\r\nD001,S001,M01,2,12.50\r\n"],
    "上传.csv",
    { type: "text/csv" }
  );

  const result = await readCsvFile(file);

  assert.equal(result.ok, true);
  assert.equal(result.rows.length, 1);
  assert.equal(result.rows[0].fileName, "上传.csv");
  assert.equal(result.rows[0].unitPriceCents, 1250);
});

test("readCsvFile 对非法 UTF-8 返回文件级错误", async () => {
  const file = new File([new Uint8Array([0x44, 0x30, 0x30, 0x31, 0xff])], "bad.csv");

  const result = await readCsvFile(file);

  assert.equal(result.ok, false);
  assert.equal(result.errors[0].recordNumber, null);
  assert.match(result.errors[0].message, /UTF-8/);
});
