import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { parseCsv } from "../src/csv.js";
import { reconcile, buildKey, EXCEPTION_TYPES } from "../src/reconcile.js";

const testDir = path.dirname(fileURLToPath(import.meta.url));
const dataPath = (fileName) => path.join(testDir, "..", "src", "data", fileName);
const readData = (fileName) => readFileSync(dataPath(fileName), "utf8");

function makeRow(documentNo, sku, quantity, unitPriceCents, overrides = {}) {
  return {
    documentNo,
    supplierCode: "S001",
    sku,
    quantity,
    unitPriceCents,
    fileName: "内存数据.csv",
    recordNumber: 2,
    ...overrides,
  };
}

function findException(result, type, sku) {
  return result.exceptions.find((item) => item.type === type && item.sku === sku);
}

test("两侧完全一致时不产生异常", () => {
  const row = makeRow("D001", "M01", 10, 1250);
  const result = reconcile([row], [{ ...row }]);

  assert.equal(result.lines.length, 1);
  assert.equal(result.lines[0].status, "matched");
  assert.equal(result.lines[0].exceptions.length, 0);
  assert.equal(result.exceptions.length, 0);
  assert.deepEqual(result.summary, {
    purchaseRowCount: 1,
    deliveryRowCount: 1,
    keyCount: 1,
    matchedKeyCount: 1,
    exceptionKeyCount: 0,
    exceptionCount: 0,
    missingPurchaseCount: 0,
    missingDeliveryCount: 0,
    duplicateCount: 0,
    byType: {
      [EXCEPTION_TYPES.QUANTITY]: 0,
      [EXCEPTION_TYPES.PRICE]: 0,
      [EXCEPTION_TYPES.DUPLICATE]: 0,
      [EXCEPTION_TYPES.MISSING]: 0,
    },
  });
});

test("数量不符：保留两侧记录并给出差额", () => {
  const purchase = makeRow("D002", "M02", 10, 1800, { recordNumber: 2 });
  const delivery = makeRow("D002", "M02", 12, 1800, {
    fileName: "送货.csv",
    recordNumber: 3,
  });

  const result = reconcile([purchase], [delivery]);

  assert.equal(result.exceptions.length, 1);
  const exception = result.exceptions[0];
  assert.equal(exception.type, EXCEPTION_TYPES.QUANTITY);
  assert.equal(exception.quantityDiff, 2);
  assert.equal(exception.purchaseRows[0].quantity, 10);
  assert.equal(exception.deliveryRows[0].quantity, 12);
  assert.equal(exception.purchase.recordNumber, 2);
  assert.equal(exception.delivery.fileName, "送货.csv");
  assert.match(exception.message, /数量不符/);
  assert.match(exception.message, /\+2/);
  assert.equal(result.lines[0].status, "diff");
});

test("单价差异：按整数分比较", () => {
  const purchase = makeRow("D003", "M03", 5, 2000);
  const delivery = makeRow("D003", "M03", 5, 2200);

  const result = reconcile([purchase], [delivery]);

  assert.equal(result.exceptions.length, 1);
  const exception = result.exceptions[0];
  assert.equal(exception.type, EXCEPTION_TYPES.PRICE);
  assert.equal(exception.priceDiffCents, 200);
  assert.match(exception.message, /20\.00/);
  assert.match(exception.message, /22\.00/);
});

test("同一键同时存在数量与单价差异时分别产生两条异常", () => {
  const purchase = makeRow("D007", "M07", 8, 2500);
  const delivery = makeRow("D007", "M07", 9, 2600);

  const result = reconcile([purchase], [delivery]);

  assert.equal(result.exceptions.length, 2);
  assert.deepEqual(
    result.exceptions.map((item) => item.type),
    [EXCEPTION_TYPES.QUANTITY, EXCEPTION_TYPES.PRICE]
  );
  assert.equal(result.lines[0].exceptions.length, 2);
  assert.equal(result.lines[0].status, "diff");
});

test("重复计账：多出的相同送货记录保留并合并为一条异常", () => {
  const purchase = makeRow("D006", "M06", 6, 1000, { recordNumber: 2 });
  const first = makeRow("D006", "M06", 6, 1000, { fileName: "送货.csv", recordNumber: 6 });
  const second = makeRow("D006", "M06", 6, 1000, { fileName: "送货.csv", recordNumber: 7 });

  const result = reconcile([purchase], [first, second]);

  assert.equal(result.exceptions.length, 1);
  const exception = result.exceptions[0];
  assert.equal(exception.type, EXCEPTION_TYPES.DUPLICATE);
  assert.equal(exception.duplicatedSide, "delivery");
  assert.equal(exception.duplicateCount, 1);
  assert.deepEqual(
    exception.deliveryRows.map((row) => row.recordNumber),
    [6, 7]
  );
  assert.equal(exception.purchaseRows.length, 1);
  assert.equal(result.lines[0].status, "duplicate");
  assert.equal(result.summary.duplicateCount, 1);
});

test("单边缺失：采购缺失与送货缺失分方向识别", () => {
  const purchaseOnly = makeRow("D004", "M04", 4, 3000);
  const deliveryOnly = makeRow("D005", "M05", 3, 4000);

  const result = reconcile([purchaseOnly], [deliveryOnly]);

  assert.equal(result.exceptions.length, 2);
  const missingDelivery = result.exceptions.find((item) => item.sku === "M04");
  const missingPurchase = result.exceptions.find((item) => item.sku === "M05");
  assert.equal(missingDelivery.type, EXCEPTION_TYPES.MISSING);
  assert.equal(missingDelivery.missingSide, "delivery");
  assert.equal(missingDelivery.purchaseRows.length, 1);
  assert.equal(missingDelivery.deliveryRows.length, 0);
  assert.equal(missingPurchase.missingSide, "purchase");
  assert.equal(missingPurchase.deliveryRows.length, 1);
  assert.equal(result.summary.missingDeliveryCount, 1);
  assert.equal(result.summary.missingPurchaseCount, 1);
  assert.ok(result.lines.every((line) => line.status === "missing"));
});

test("多出的送货记录与已配对记录不同时按采购缺失处理", () => {
  const purchase = makeRow("D009", "M10", 5, 1000);
  const same = makeRow("D009", "M10", 5, 1000, { recordNumber: 6 });
  const different = makeRow("D009", "M10", 7, 1000, { recordNumber: 7 });

  const result = reconcile([purchase], [same, different]);

  assert.equal(result.exceptions.length, 1);
  assert.equal(result.exceptions[0].type, EXCEPTION_TYPES.MISSING);
  assert.equal(result.exceptions[0].missingSide, "purchase");
  assert.equal(result.exceptions[0].missingRows[0].recordNumber, 7);
});

test("同一键多行换行序不产生误报", () => {
  // 两份 CSV 各有「10 件 × 2 元」和「20 件 × 4 元」，只颠倒送货侧行序。
  const purchase = [
    makeRow("D010", "M11", 10, 200, { recordNumber: 2 }),
    makeRow("D010", "M11", 20, 400, { recordNumber: 3 }),
  ];
  const delivery = [
    makeRow("D010", "M11", 20, 400, { fileName: "送货.csv", recordNumber: 2 }),
    makeRow("D010", "M11", 10, 200, { fileName: "送货.csv", recordNumber: 3 }),
  ];

  const result = reconcile(purchase, delivery);

  assert.equal(result.lines[0].status, "matched");
  assert.equal(result.exceptions.length, 0);
  assert.equal(result.summary.exceptionCount, 0);
});

test("两侧同记录各重复两次时分别上报重复计账", () => {
  const purchase = [
    makeRow("D011", "M12", 10, 2000, { recordNumber: 2 }),
    makeRow("D011", "M12", 10, 2000, { recordNumber: 3 }),
  ];
  const delivery = [
    makeRow("D011", "M12", 10, 2000, { fileName: "送货.csv", recordNumber: 2 }),
    makeRow("D011", "M12", 10, 2000, { fileName: "送货.csv", recordNumber: 3 }),
  ];

  const result = reconcile(purchase, delivery);

  assert.equal(result.exceptions.length, 2);
  const purchaseDup = result.exceptions.find((item) => item.duplicatedSide === "purchase");
  const deliveryDup = result.exceptions.find((item) => item.duplicatedSide === "delivery");
  assert.equal(purchaseDup.duplicateCount, 1);
  assert.equal(deliveryDup.duplicateCount, 1);
  assert.deepEqual(purchaseDup.duplicateRows.map((row) => row.recordNumber), [3]);
  assert.deepEqual(deliveryDup.duplicateRows.map((row) => row.recordNumber), [3]);
  assert.equal(result.summary.duplicateCount, 2);
  assert.equal(result.lines[0].status, "duplicate");
});

test("同键两行：首行一致、次行差 1 件时只报一条数量差异", () => {
  const purchase = [
    makeRow("D012", "M13", 10, 1500, { recordNumber: 2 }),
    makeRow("D012", "M13", 20, 1500, { recordNumber: 3 }),
  ];
  const delivery = [
    makeRow("D012", "M13", 10, 1500, { fileName: "送货.csv", recordNumber: 2 }),
    makeRow("D012", "M13", 21, 1500, { fileName: "送货.csv", recordNumber: 3 }),
  ];

  const result = reconcile(purchase, delivery);

  assert.equal(result.exceptions.length, 1);
  const exception = result.exceptions[0];
  assert.equal(exception.type, EXCEPTION_TYPES.QUANTITY);
  assert.equal(exception.quantityDiff, 1);
  assert.equal(exception.purchase.recordNumber, 3);
  assert.equal(exception.delivery.quantity, 21);
  assert.match(exception.message, /\+1/);
});

test("空输入返回空结果", () => {
  const result = reconcile([], []);

  assert.deepEqual(result.lines, []);
  assert.deepEqual(result.exceptions, []);
  assert.equal(result.summary.keyCount, 0);
  assert.equal(result.summary.exceptionCount, 0);
});

test("匹配键由单据编号、供应商编码、物料编码组成", () => {
  assert.equal(buildKey(makeRow("D001", "M01", 1, 100)), "D001|S001|M01");

  const purchaseM08 = makeRow("D008", "M08", 2, 1500);
  const deliveryM09 = makeRow("D008", "M09", 2, 1500);
  const result = reconcile([purchaseM08], [deliveryM09]);

  assert.equal(result.lines.length, 2);
  assert.equal(result.exceptions.length, 2);
});

test("演示 CSV 端到端：逐键结果与预期一致", () => {
  const purchase = parseCsv(readData("purchase-demo.csv"), "purchase-demo.csv");
  const delivery = parseCsv(readData("delivery-demo.csv"), "delivery-demo.csv");
  assert.equal(purchase.ok, true);
  assert.equal(delivery.ok, true);

  const result = reconcile(purchase.rows, delivery.rows);

  assert.deepEqual(
    result.lines.map((line) => [line.documentNo, line.sku, line.status]),
    [
      ["D001", "M01", "matched"],
      ["D002", "M02", "diff"],
      ["D003", "M03", "diff"],
      ["D004", "M04", "missing"],
      ["D005", "M05", "missing"],
      ["D006", "M06", "duplicate"],
      ["D007", "M07", "diff"],
      ["D008", "M08", "missing"],
      ["D008", "M09", "missing"],
    ]
  );

  assert.equal(result.summary.keyCount, 9);
  assert.equal(result.summary.matchedKeyCount, 1);
  assert.equal(result.summary.exceptionCount, 9);
  assert.deepEqual(result.summary.byType, {
    [EXCEPTION_TYPES.QUANTITY]: 2,
    [EXCEPTION_TYPES.PRICE]: 2,
    [EXCEPTION_TYPES.DUPLICATE]: 1,
    [EXCEPTION_TYPES.MISSING]: 4,
  });

  const quantity = findException(result, EXCEPTION_TYPES.QUANTITY, "M02");
  assert.equal(quantity.quantityDiff, 2);

  const price = findException(result, EXCEPTION_TYPES.PRICE, "M03");
  assert.equal(price.priceDiffCents, 200);

  const duplicate = findException(result, EXCEPTION_TYPES.DUPLICATE, "M06");
  assert.equal(duplicate.duplicatedSide, "delivery");
  assert.deepEqual(
    duplicate.deliveryRows.map((row) => row.recordNumber),
    [6, 7]
  );
  assert.match(duplicate.deliveryRows[0].fileName, /delivery-demo\.csv/);

  const m08 = result.lines.find((line) => line.sku === "M08");
  const m09 = result.lines.find((line) => line.sku === "M09");
  assert.equal(m08.exceptions[0].missingSide, "delivery");
  assert.equal(m09.exceptions[0].missingSide, "purchase");
});
